import fs from 'node:fs';
import path from 'node:path';

const manifestPath = path.resolve('android/app/src/main/AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) {
  throw new Error(`Android manifest not found: ${manifestPath}`);
}
let xml = fs.readFileSync(manifestPath, 'utf8');
// Lock the launcher activity to portrait so the game layout stays consistent.
const activityPattern = /<activity\b([^>]*\bandroid:name="[^"]*(?:MainActivity|\.MainActivity)[^"]*"[^>]*)>/;
if (!activityPattern.test(xml)) {
  throw new Error('Could not find the Capacitor MainActivity in AndroidManifest.xml');
}
xml = xml.replace(activityPattern, (match, attrs) => {
  const cleaned = attrs.replace(/\s+android:screenOrientation="[^"]*"/g, '');
  return `<activity${cleaned} android:screenOrientation="portrait">`;
});
fs.writeFileSync(manifestPath, xml);
console.log('Configured Puzzle Arrow for portrait orientation.');
