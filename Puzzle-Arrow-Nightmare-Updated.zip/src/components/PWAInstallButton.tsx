import React, { useState } from 'react';
import { Download, Share, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'compact' | 'card';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'compact',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    if (variant === 'card') {
      return (
        <button
          type="button"
          onClick={install}
          className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between rounded-2xl bg-[#0E1814] border border-emerald-500/30 hover:border-emerald-400/50 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3 text-left">
            <Download className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <div className="text-sm font-medium text-zinc-100">
                Install App
              </div>
              <div className="text-xs text-zinc-400">
                Add Puzzle Arrow to your home screen for offline play
              </div>
            </div>
          </div>
          <span className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-emerald-400 text-black shrink-0 ml-2">
            Install
          </span>
        </button>
      );
    }

    return (
      <button
        type="button"
        onClick={install}
        aria-label="Install Puzzle Arrow app"
        className="min-h-[40px] px-2.5 flex items-center gap-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 hover:bg-emerald-500/25 transition-colors cursor-pointer whitespace-nowrap"
      >
        <Download className="w-4 h-4 shrink-0" />
        <span className="text-xs font-medium hidden sm:inline">Install</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        {variant === 'card' ? (
          <button
            type="button"
            onClick={() => setShowIOSGuide(true)}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between rounded-2xl bg-[#131317] border border-white/[0.1] hover:border-white/[0.2] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3 text-left">
              <Share className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <div className="text-sm font-medium text-zinc-100">
                  Install on iOS
                </div>
                <div className="text-xs text-zinc-400">
                  Add Puzzle Arrow to iPhone or iPad Home Screen
                </div>
              </div>
            </div>
            <span className="text-xs font-medium px-2.5 py-1 rounded-lg bg-zinc-800 text-zinc-200 shrink-0 ml-2">
              Guide
            </span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setShowIOSGuide(true)}
            aria-label="Install on iOS"
            className="min-h-[40px] px-2.5 flex items-center gap-1.5 rounded-xl bg-[#121216] border border-white/[0.09] text-zinc-200 hover:border-white/[0.2] transition-colors cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-xs font-medium hidden sm:inline">Install</span>
          </button>
        )}

        {showIOSGuide && (
          <div
            className="fixed inset-0 z-[60] flex items-center justify-center bg-black/85 backdrop-blur-sm p-4"
            onPointerDown={(e) => {
              if (e.target === e.currentTarget) setShowIOSGuide(false);
            }}
            role="dialog"
            aria-modal="true"
            aria-label="Install on iPhone or iPad"
          >
            <div className="w-full max-w-sm rounded-3xl bg-[#0C0C10] border border-white/[0.12] p-6 shadow-2xl animate-pop-in">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-display text-lg font-semibold text-white">
                  Install on iPhone / iPad
                </h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  aria-label="Close guide"
                  className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-zinc-400 hover:text-white hover:bg-white/[0.06] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <ol className="space-y-2.5 text-sm text-zinc-300">
                <li>
                  1. Tap the <strong className="text-white">Share</strong> button in the Safari toolbar.
                </li>
                <li>
                  2. Scroll down and tap <strong className="text-white">Add to Home Screen</strong>.
                </li>
                <li>
                  3. Tap <strong className="text-white">Add</strong> to launch full-screen offline.
                </li>
              </ol>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full min-h-[44px] rounded-2xl bg-white text-black text-sm font-semibold hover:bg-zinc-200 transition-colors cursor-pointer"
              >
                Got it
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
