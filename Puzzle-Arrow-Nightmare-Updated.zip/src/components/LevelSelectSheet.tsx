import React, { useMemo, useState } from 'react';
import { Lock, Shuffle, Star, X } from 'lucide-react';
import { LevelProgress } from '../types/game';

interface LevelSelectSheetProps {
  isOpen: boolean;
  currentLevel: number;
  maxUnlockedLevel: number;
  totalLevels?: number;
  progress: Record<number, LevelProgress>;
  onSelectLevel: (level: number) => void;
  onPlayEndless: () => void;
  onClose: () => void;
}

const TIERS = [
  { label: '1–50', start: 1, end: 50 },
  { label: '51–100', start: 51, end: 100 },
  { label: '101–150', start: 101, end: 150 },
];

export const LevelSelectSheet: React.FC<LevelSelectSheetProps> = ({
  isOpen,
  currentLevel,
  maxUnlockedLevel,
  totalLevels = 150,
  progress,
  onSelectLevel,
  onPlayEndless,
  onClose,
}) => {
  const initialTier = currentLevel > 100 ? 2 : currentLevel > 50 ? 1 : 0;
  const [tierIdx, setTierIdx] = useState<number>(initialTier);

  const visibleLevels = useMemo(() => {
    const tier = TIERS[tierIdx] ?? TIERS[0];
    const end = Math.min(tier.end, totalLevels);
    return Array.from({ length: end - tier.start + 1 }, (_, i) => tier.start + i);
  }, [tierIdx, totalLevels]);

  if (!isOpen) return null;

  const completedCount = Object.keys(progress).length;
  const totalStars = Object.values(progress).reduce((acc, p) => acc + p.stars, 0);

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm"
      onPointerDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label="Select Level"
    >
      <div className="w-full max-w-lg max-h-[85dvh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-[#0A0A0D] border border-white/[0.1] shadow-2xl overflow-hidden animate-pop-in">
        {/* Android Bottom Sheet Drag Handle */}
        <div className="sm:hidden flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-zinc-700" aria-hidden="true" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.07]">
          <div>
            <h2 className="font-display text-lg font-semibold text-zinc-100">
              Chapters · 150 Levels
            </h2>
            <p className="text-xs text-zinc-400 tabular-nums mt-0.5">
              {completedCount} cleared · {totalStars} stars earned
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close level selector"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.06] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tier Selector Tabs */}
        <div className="px-5 pt-3">
          <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-black border border-white/[0.06]">
            {TIERS.map((tier, idx) => (
              <button
                key={tier.label}
                type="button"
                onClick={() => setTierIdx(idx)}
                className={`min-h-[38px] rounded-lg text-xs font-mono font-medium transition-colors cursor-pointer ${
                  tierIdx === idx
                    ? 'bg-[#1D1D24] text-white'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {tier.label}
              </button>
            ))}
          </div>
        </div>

        {/* Scrollable Grid */}
        <div className="flex-1 overflow-y-auto dark-scroll p-5">
          <div className="grid grid-cols-5 gap-2.5">
            {visibleLevels.map((lvl) => {
              const unlocked = lvl <= maxUnlockedLevel;
              const isCurrent = lvl === currentLevel;
              const stats = progress[lvl];

              return (
                <button
                  key={lvl}
                  type="button"
                  disabled={!unlocked}
                  onClick={() => {
                    onSelectLevel(lvl);
                    onClose();
                  }}
                  className={`relative min-h-[54px] flex flex-col items-center justify-center rounded-2xl border transition-all tabular-nums ${
                    isCurrent
                      ? 'bg-white/10 border-white/60 text-white'
                      : unlocked
                      ? 'bg-[#131317] border-white/[0.08] text-zinc-100 hover:border-white/25 active:scale-[0.95] cursor-pointer'
                      : 'bg-[#08080A] border-white/[0.03] text-zinc-700 cursor-not-allowed'
                  }`}
                >
                  {unlocked ? (
                    <>
                      <span className="font-display text-base font-semibold leading-none">
                        {lvl}
                      </span>
                      <div className="flex items-center gap-0.5 mt-1.5" aria-hidden="true">
                        {[1, 2, 3].map((s) => (
                          <Star
                            key={s}
                            className={`w-2.5 h-2.5 ${
                              stats && s <= stats.stars
                                ? 'text-amber-400 fill-amber-400'
                                : 'text-zinc-700'
                            }`}
                          />
                        ))}
                      </div>
                    </>
                  ) : (
                    <Lock className="w-4 h-4 text-zinc-700" aria-label={`Level ${lvl} locked`} />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Action: Extreme 20x20-24x24 Procedural Maze */}
        <div className="p-4 border-t border-white/[0.07] bg-[#070709]">
          <button
            type="button"
            onClick={() => {
              onPlayEndless();
              onClose();
            }}
            className="w-full min-h-[48px] flex items-center justify-center gap-2.5 rounded-2xl bg-[#1A1215] hover:bg-[#24161B] border border-rose-500/35 text-rose-200 font-semibold text-sm transition-colors active:scale-[0.98] cursor-pointer whitespace-nowrap"
          >
            <Shuffle className="w-4 h-4 text-rose-400" />
            <span>Play Extreme Maze (20×20+)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
