import React, { useState } from 'react';
import {
  Check,
  ChevronDown,
  CloudRain,
  Clock,
  Copy,
  Heart,
  Package,
  Palette,
  Radio,
  Smartphone,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import {
  AmbientSoundscapePrefs,
  ChallengeMode,
  ColorMode,
  UserPreferences,
} from '../types/game';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsSheetProps {
  isOpen: boolean;
  prefs: UserPreferences;
  onUpdatePrefs: (patch: Partial<UserPreferences>) => void;
  onClose: () => void;
}

const SOUNDSCAPE_LAYERS: {
  key: keyof AmbientSoundscapePrefs;
  title: string;
  description: string;
  icon: React.FC<{ className?: string }>;
  activeText: string;
  activeBadge: string;
}[] = [
  {
    key: 'digitalRain',
    title: 'Digital Rain',
    description: 'Soft rainfall hiss with faint chimes',
    icon: CloudRain,
    activeText: 'text-sky-400',
    activeBadge: 'bg-sky-500/15 text-sky-300',
  },
  {
    key: 'lowHum',
    title: 'Low Hum',
    description: 'Warm sub-octave ambient drone',
    icon: Radio,
    activeText: 'text-violet-400',
    activeBadge: 'bg-violet-500/15 text-violet-300',
  },
  {
    key: 'clockworkTicks',
    title: 'Clockwork Ticks',
    description: 'Steady watchmaker pulse',
    icon: Clock,
    activeText: 'text-amber-400',
    activeBadge: 'bg-amber-500/15 text-amber-300',
  },
];

export const SettingsSheet: React.FC<SettingsSheetProps> = ({
  isOpen,
  prefs,
  onUpdatePrefs,
  onClose,
}) => {
  const [showPlayGuide, setShowPlayGuide] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  if (!isOpen) return null;

  const currentOrigin =
    typeof window !== 'undefined' ? window.location.origin : '';

  const handleCopyOrigin = async () => {
    if (!currentOrigin) return;
    try {
      await navigator.clipboard.writeText(currentOrigin);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 1800);
    } catch {
      // Clipboard unavailable
    }
  };

  const toggleSoundscapeLayer = (key: keyof AmbientSoundscapePrefs) => {
    onUpdatePrefs({
      soundscape: {
        ...prefs.soundscape,
        [key]: !prefs.soundscape[key],
      },
    });
  };

  const activeLayerCount = Object.values(prefs.soundscape).filter(Boolean).length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm"
      onPointerDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label="Game Preferences"
    >
      <div className="w-full max-w-md max-h-[86dvh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-[#0A0A0D] border border-white/[0.1] shadow-2xl overflow-hidden animate-pop-in">
        {/* Mobile Drag Handle */}
        <div className="sm:hidden flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-zinc-700" aria-hidden="true" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.07] shrink-0">
          <h2 className="font-display text-lg font-semibold text-zinc-100">
            Preferences
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close settings"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.06] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto dark-scroll p-5 space-y-4">
          {/* Sound Effects Toggle */}
          <button
            type="button"
            onClick={() => onUpdatePrefs({ soundEnabled: !prefs.soundEnabled })}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between rounded-2xl bg-[#131317] border border-white/[0.07] hover:border-white/[0.14] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3 text-left">
              {prefs.soundEnabled ? (
                <Volume2 className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <VolumeX className="w-5 h-5 text-zinc-500 shrink-0" />
              )}
              <div>
                <div className="text-sm font-medium text-zinc-100">Sound Effects</div>
                <div className="text-xs text-zinc-400">Harmonic chimes on escape</div>
              </div>
            </div>
            <span
              className={`text-xs font-medium px-2.5 py-1 rounded-lg ${
                prefs.soundEnabled
                  ? 'bg-emerald-500/15 text-emerald-300'
                  : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              {prefs.soundEnabled ? 'On' : 'Off'}
            </span>
          </button>

          {/* Granular Ambient Soundscape Menu (Independent of SFX) */}
          <div className="p-4 rounded-2xl bg-[#131317] border border-white/[0.07] space-y-3">
            <div className="flex items-baseline justify-between gap-2">
              <div>
                <div className="text-sm font-medium text-zinc-100">
                  Ambient Soundscape
                </div>
                <div className="text-xs text-zinc-400">
                  Layer textures independently of sound effects
                </div>
              </div>
              <span className="text-xs font-mono tabular-nums text-zinc-400 shrink-0">
                {activeLayerCount} active
              </span>
            </div>

            <div className="space-y-2">
              {SOUNDSCAPE_LAYERS.map((layer) => {
                const Icon = layer.icon;
                const enabled = prefs.soundscape[layer.key];
                return (
                  <button
                    key={layer.key}
                    type="button"
                    onClick={() => toggleSoundscapeLayer(layer.key)}
                    aria-pressed={enabled}
                    className={`w-full min-h-[48px] px-3.5 py-2.5 flex items-center justify-between rounded-xl border transition-colors cursor-pointer ${
                      enabled
                        ? 'bg-[#191921] border-white/[0.14]'
                        : 'bg-black/45 border-white/[0.05] hover:border-white/[0.1]'
                    }`}
                  >
                    <div className="flex items-center gap-3 text-left min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          enabled ? layer.activeText : 'text-zinc-500'
                        }`}
                      />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-zinc-100 truncate">
                          {layer.title}
                        </div>
                        <div className="text-xs text-zinc-400 truncate">
                          {layer.description}
                        </div>
                      </div>
                    </div>
                    <span
                      className={`text-xs font-medium px-2.5 py-1 rounded-lg shrink-0 ml-2 ${
                        enabled ? layer.activeBadge : 'bg-zinc-800/90 text-zinc-500'
                      }`}
                    >
                      {enabled ? 'On' : 'Off'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Haptics Toggle */}
          <button
            type="button"
            onClick={() => onUpdatePrefs({ hapticsEnabled: !prefs.hapticsEnabled })}
            className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between rounded-2xl bg-[#131317] border border-white/[0.07] hover:border-white/[0.14] transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3 text-left">
              <Smartphone
                className={`w-5 h-5 shrink-0 ${
                  prefs.hapticsEnabled ? 'text-sky-400' : 'text-zinc-500'
                }`}
              />
              <div>
                <div className="text-sm font-medium text-zinc-100">Android Haptics</div>
                <div className="text-xs text-zinc-400">Tactile vibration feedback</div>
              </div>
            </div>
            <span
              className={`text-xs font-medium px-2.5 py-1 rounded-lg ${
                prefs.hapticsEnabled
                  ? 'bg-sky-500/15 text-sky-300'
                  : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              {prefs.hapticsEnabled ? 'On' : 'Off'}
            </span>
          </button>

          {/* Path Style Selector */}
          <div className="p-4 rounded-2xl bg-[#131317] border border-white/[0.07] space-y-3">
            <div className="flex items-center gap-3">
              <Palette className="w-5 h-5 text-zinc-200 shrink-0" />
              <div>
                <div className="text-sm font-medium text-zinc-100">Path Style</div>
                <div className="text-xs text-zinc-400">Minimal platinum ink or prism tones</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-black/70 border border-white/[0.05]">
              {(['platinum', 'prism'] as ColorMode[]).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => onUpdatePrefs({ colorMode: mode })}
                  className={`min-h-[40px] rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    prefs.colorMode === mode
                      ? 'bg-[#22222A] text-white shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {mode === 'platinum' ? 'Platinum Ink' : 'Prism Tones'}
                </button>
              ))}
            </div>
          </div>

          {/* Challenge Mode Selector */}
          <div className="p-4 rounded-2xl bg-[#131317] border border-white/[0.07] space-y-3">
            <div className="flex items-center gap-3">
              <Heart className="w-5 h-5 text-rose-500 shrink-0" />
              <div>
                <div className="text-sm font-medium text-zinc-100">Escape Rule</div>
                <div className="text-xs text-zinc-400">3 Hearts classic or unlimited Zen</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-black/70 border border-white/[0.05]">
              {(['hearts', 'zen'] as ChallengeMode[]).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => onUpdatePrefs({ challengeMode: mode })}
                  className={`min-h-[40px] rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    prefs.challengeMode === mode
                      ? 'bg-[#22222A] text-white shadow-sm'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {mode === 'hearts' ? '3 Hearts' : 'Zen Mode'}
                </button>
              ))}
            </div>
          </div>

          {/* Install App & Google Play Store TWA Readiness */}
          <PWAInstallButton variant="card" />

          <div className="rounded-2xl bg-[#131317] border border-white/[0.07] overflow-hidden">
            <button
              type="button"
              onClick={() => setShowPlayGuide((prev) => !prev)}
              aria-expanded={showPlayGuide}
              className="w-full min-h-[56px] px-4 py-3 flex items-center justify-between hover:bg-white/[0.02] transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 text-left">
                <Package className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <div className="text-sm font-medium text-zinc-100">
                    Google Play Store (.aab)
                  </div>
                  <div className="text-xs text-zinc-400">
                    PWA &amp; TWA packaging details for Play Console
                  </div>
                </div>
              </div>
              <ChevronDown
                className={`w-4 h-4 text-zinc-400 transition-transform duration-200 ${
                  showPlayGuide ? 'rotate-180' : ''
                }`}
              />
            </button>

            {showPlayGuide && (
              <div className="px-4 pb-4 pt-1 border-t border-white/[0.06] space-y-3 text-xs text-zinc-300 leading-relaxed">
                <p className="text-zinc-400">
                  Puzzle Arrow includes an installable Web App Manifest, offline
                  Service Worker, maskable Android icons, and{' '}
                  <code className="text-zinc-200 font-mono">
                    /.well-known/assetlinks.json
                  </code>
                  . To generate the signed{' '}
                  <strong className="text-white">.aab</strong> bundle required by
                  Google Play:
                </p>
                <ol className="space-y-1.5 text-zinc-300">
                  <li>
                    1. Publish/share this app to get your public HTTPS URL.
                  </li>
                  <li>
                    2. Enter that URL in{' '}
                    <strong className="text-white">PWABuilder</strong> or run{' '}
                    <code className="text-zinc-200 font-mono">
                      npx @bubblewrap/cli init
                    </code>{' '}
                    to export an Android App Bundle (<strong className="text-white">.aab</strong>).
                  </li>
                  <li>
                    3. Paste your Play App Signing SHA-256 fingerprint into{' '}
                    <code className="text-zinc-200 font-mono">
                      public/.well-known/assetlinks.json
                    </code>{' '}
                    and upload the <strong className="text-white">.aab</strong> to
                    Google Play Console.
                  </li>
                </ol>

                {currentOrigin && (
                  <button
                    type="button"
                    onClick={handleCopyOrigin}
                    className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-black/70 border border-white/[0.08] hover:border-white/[0.16] flex items-center justify-between gap-2 transition-colors cursor-pointer"
                  >
                    <span className="font-mono text-[11px] text-zinc-400 truncate">
                      {currentOrigin}
                    </span>
                    <span className="flex items-center gap-1 text-emerald-400 font-medium shrink-0">
                      {copiedUrl ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          Copied
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          Copy URL
                        </>
                      )}
                    </span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
