import React from 'react';
import { Award, CheckCircle2, Crown, Flame, Shield, Sparkles } from 'lucide-react';
import { DailyBadgeDefinition } from '../types/game';

interface BadgeEmblemProps {
  badge: DailyBadgeDefinition;
  unlocked: boolean;
  size?: 'sm' | 'md';
}

const ACCENT_STYLES: Record<
  DailyBadgeDefinition['accent'],
  { border: string; bg: string; icon: string; ring: string }
> = {
  emerald: {
    border: 'border-emerald-400/45',
    bg: 'bg-emerald-500/12',
    icon: 'text-emerald-300',
    ring: 'shadow-[0_0_20px_rgba(52,211,153,0.16)]',
  },
  amber: {
    border: 'border-amber-400/45',
    bg: 'bg-amber-500/12',
    icon: 'text-amber-300',
    ring: 'shadow-[0_0_20px_rgba(251,191,36,0.16)]',
  },
  sky: {
    border: 'border-sky-400/45',
    bg: 'bg-sky-500/12',
    icon: 'text-sky-300',
    ring: 'shadow-[0_0_20px_rgba(56,189,248,0.16)]',
  },
  rose: {
    border: 'border-rose-400/45',
    bg: 'bg-rose-500/12',
    icon: 'text-rose-300',
    ring: 'shadow-[0_0_20px_rgba(251,113,133,0.16)]',
  },
  violet: {
    border: 'border-violet-400/45',
    bg: 'bg-violet-500/12',
    icon: 'text-violet-300',
    ring: 'shadow-[0_0_20px_rgba(167,139,250,0.16)]',
  },
  white: {
    border: 'border-white/50',
    bg: 'bg-white/10',
    icon: 'text-white',
    ring: 'shadow-[0_0_20px_rgba(255,255,255,0.14)]',
  },
};

function renderBadgeIcon(id: string, className: string) {
  switch (id) {
    case 'first_light':
      return <Sparkles className={className} strokeWidth={2} />;
    case 'flawless_run':
      return <CheckCircle2 className={className} strokeWidth={2} />;
    case 'triad_streak':
      return <Flame className={className} strokeWidth={2} />;
    case 'five_victories':
      return <Shield className={className} strokeWidth={2} />;
    case 'obsidian_week':
      return <Award className={className} strokeWidth={2} />;
    case 'grandmaster_seal':
      return <Crown className={className} strokeWidth={2} />;
    default:
      return <Award className={className} strokeWidth={2} />;
  }
}

export const BadgeEmblem: React.FC<BadgeEmblemProps> = ({
  badge,
  unlocked,
  size = 'md',
}) => {
  const style = ACCENT_STYLES[badge.accent];
  const dim = size === 'sm' ? 'w-10 h-10 rounded-xl' : 'w-12 h-12 rounded-2xl';
  const iconDim = size === 'sm' ? 'w-5 h-5' : 'w-6 h-6';

  return (
    <div
      className={`${dim} flex items-center justify-center border shrink-0 transition-all ${
        unlocked
          ? `${style.bg} ${style.border} ${style.ring}`
          : 'bg-[#0C0C10] border-white/[0.06] opacity-40'
      }`}
      aria-hidden="true"
    >
      {renderBadgeIcon(
        badge.id,
        `${iconDim} ${unlocked ? style.icon : 'text-zinc-600'}`
      )}
    </div>
  );
};
