import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-[max(4.5rem,calc(env(safe-area-inset-bottom)+4.25rem))] left-1/2 -translate-x-1/2 z-40 flex items-center gap-2 rounded-xl bg-[#16140D] border border-amber-500/35 px-3 py-1.5 text-xs font-medium text-amber-200 shadow-lg whitespace-nowrap"
    >
      <WifiOff className="w-3.5 h-3.5 text-amber-400 shrink-0" aria-hidden="true" />
      <span>Offline Mode — Playing from local cache</span>
    </div>
  );
};
