import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      message: error?.message || 'Unexpected application error',
    };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[100dvh] w-full bg-black text-zinc-100 flex items-center justify-center p-6">
          <div className="w-full max-w-sm rounded-3xl bg-[#0C0C10] border border-white/[0.1] p-6 text-center space-y-4">
            <h1 className="font-display text-xl font-semibold text-white">
              Something went wrong
            </h1>
            <p className="text-xs text-zinc-400 break-words">
              {this.state.message}
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="w-full min-h-[44px] rounded-2xl bg-white text-black text-sm font-semibold hover:bg-zinc-200 transition-colors cursor-pointer"
            >
              Reload Puzzle Arrow
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
