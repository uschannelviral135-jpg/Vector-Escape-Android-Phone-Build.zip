import React, { useEffect, useState } from 'react';
import { Calendar, Check, Clock, Flame, Play, X } from 'lucide-react';
import {
  computeEffectiveStreak,
  DAILY_BADGES,
  formatReadableDate,
  formatTimeUntilMidnight,
  getTodayDateKey,
  getYesterdayDateKey,
} from '../engine/dailyChallenge';
import { DailyProgressState, LevelConfig } from '../types/game';
import { BadgeEmblem } from './BadgeEmblem';

interface DailyChallengeSheetProps {
  isOpen: boolean;
  dailyState: DailyProgressState;
  dailySequence: LevelConfig[];
  todayKey: string;
  onStartDaily: () => void;
  onClose: () => void;
}

export const DailyChallengeSheet: React.FC<DailyChallengeSheetProps> = ({
  isOpen,
  dailyState,
  dailySequence,
  todayKey,
  onStartDaily,
  onClose,
}) => {
  const [countdown, setCountdown] = useState<string>(() =>
    formatTimeUntilMidnight()
  );

  useEffect(() => {
    if (!isOpen) return;
    setCountdown(formatTimeUntilMidnight());
    const id = window.setInterval(() => {
      setCountdown(formatTimeUntilMidnight());
    }, 1000);
    return () => window.clearInterval(id);
  }, [isOpen]);

  if (!isOpen) return null;

  const todayRecord = dailyState.completedDates[todayKey];
  const isCompletedToday = Boolean(todayRecord);
  const yesterdayKey = getYesterdayDateKey(new Date());
  const effectiveStreak = computeEffectiveStreak(
    dailyState,
    todayKey || getTodayDateKey(),
    yesterdayKey
  );
  const totalCompleted = Object.keys(dailyState.completedDates).length;

  const activeStageIdx =
    dailyState.activeRun && dailyState.activeRun.dateKey === todayKey
      ? dailyState.activeRun.stageIndex
      : 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm"
      onPointerDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label="Daily Challenge"
    >
      <div className="w-full max-w-lg max-h-[88dvh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-[#0A0A0D] border border-white/[0.1] shadow-2xl overflow-hidden animate-pop-in">
        {/* Android Bottom Sheet Drag Handle */}
        <div className="sm:hidden flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-zinc-700" aria-hidden="true" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.07]">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400 shrink-0" />
              <h2 className="font-display text-lg font-semibold text-white">
                Daily Sequence
              </h2>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5 tabular-nums">
              {formatReadableDate(todayKey)} · Resets in{' '}
              <span className="font-mono text-zinc-200">{countdown}</span>
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close daily challenge"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.06] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto dark-scroll p-5 space-y-6">
          {/* Streak & Total Unboxed Telemetry */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-[#111116] border border-white/[0.07]">
              <div className="text-xs text-zinc-400">Streak</div>
              <div className="mt-1 flex items-center gap-1.5 font-mono text-xl font-semibold text-white tabular-nums">
                <Flame
                  className={`w-4 h-4 ${
                    effectiveStreak > 0 ? 'text-amber-400' : 'text-zinc-600'
                  }`}
                />
                <span>{effectiveStreak}d</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#111116] border border-white/[0.07]">
              <div className="text-xs text-zinc-400">Best Streak</div>
              <div className="mt-1 font-mono text-xl font-semibold text-white tabular-nums">
                {dailyState.bestStreak}d
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#111116] border border-white/[0.07]">
              <div className="text-xs text-zinc-400">Cleared</div>
              <div className="mt-1 font-mono text-xl font-semibold text-white tabular-nums">
                {totalCompleted}
              </div>
            </div>
          </div>

          {/* Today's 3-Stage Gauntlet */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="text-sm font-medium text-zinc-200">
                Today&apos;s 3-Stage Sequence
              </h3>
              <span className="text-xs font-mono tabular-nums text-zinc-400">
                {isCompletedToday
                  ? '3 / 3 done'
                  : `${activeStageIdx} / 3 done`}
              </span>
            </div>

            <div className="space-y-2">
              {dailySequence.map((stage, idx) => {
                const stageDone = isCompletedToday || idx < activeStageIdx;
                const isCurrentStage = !isCompletedToday && idx === activeStageIdx;

                return (
                  <div
                    key={`${todayKey}-stage-${idx}`}
                    className={`px-4 py-3 rounded-2xl border flex items-center justify-between gap-3 ${
                      isCurrentStage
                        ? 'bg-[#15151C] border-amber-400/35'
                        : stageDone
                        ? 'bg-[#101614] border-emerald-500/25'
                        : 'bg-[#0E0E12] border-white/[0.06]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-sm font-medium text-zinc-100">
                        <span className="font-mono text-xs text-zinc-400">
                          0{idx + 1}
                        </span>
                        <span className="truncate">{stage.shapeName}</span>
                      </div>
                      <div className="text-xs text-zinc-400 font-mono tabular-nums mt-0.5">
                        {stage.rows}×{stage.cols} · {stage.arrows.length} arrows
                      </div>
                    </div>

                    <div className="shrink-0">
                      {stageDone ? (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-400">
                          <Check className="w-4 h-4" />
                          <span>Cleared</span>
                        </span>
                      ) : isCurrentStage ? (
                        <span className="text-xs font-medium text-amber-300">
                          Next
                        </span>
                      ) : (
                        <span className="text-xs text-zinc-600">Queued</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Exclusive Badge Rewards Vault */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-zinc-200">
                Exclusive Badges
              </h3>
              <span className="text-xs font-mono tabular-nums text-zinc-400">
                {dailyState.unlockedBadges.length} / {DAILY_BADGES.length} unlocked
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {DAILY_BADGES.map((badge) => {
                const unlocked = dailyState.unlockedBadges.includes(badge.id);
                return (
                  <div
                    key={badge.id}
                    className={`p-3 rounded-2xl border flex items-center gap-3 ${
                      unlocked
                        ? 'bg-[#131318] border-white/[0.12]'
                        : 'bg-[#0C0C10] border-white/[0.05]'
                    }`}
                  >
                    <BadgeEmblem badge={badge} unlocked={unlocked} size="sm" />
                    <div className="min-w-0">
                      <div
                        className={`text-sm font-medium truncate ${
                          unlocked ? 'text-white' : 'text-zinc-500'
                        }`}
                      >
                        {badge.title}
                      </div>
                      <div className="text-xs text-zinc-500 leading-snug mt-0.5">
                        {badge.requirement}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer CTA */}
        <div className="p-4 border-t border-white/[0.07] bg-[#070709]">
          {isCompletedToday ? (
            <div className="w-full min-h-[48px] px-4 rounded-2xl bg-[#111513] border border-emerald-500/25 flex items-center justify-between gap-3 text-sm">
              <span className="flex items-center gap-2 font-medium text-emerald-300">
                <Check className="w-4 h-4 shrink-0" />
                <span>Completed Today</span>
              </span>
              <span className="flex items-center gap-1.5 text-xs font-mono tabular-nums text-zinc-400">
                <Clock className="w-3.5 h-3.5" />
                <span>{countdown}</span>
              </span>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => {
                onStartDaily();
                onClose();
              }}
              className="w-full min-h-[48px] flex items-center justify-center gap-2 rounded-2xl bg-amber-400 hover:bg-amber-300 text-black font-semibold text-sm transition-colors active:scale-[0.98] cursor-pointer whitespace-nowrap"
            >
              <Play className="w-4 h-4 fill-black" />
              <span>
                {activeStageIdx > 0
                  ? `Continue Stage ${activeStageIdx + 1} of 3`
                  : 'Start Daily Sequence'}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
