import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { ZoomIn, ZoomOut } from 'lucide-react';
import {
  BlockedFeedback,
  ColorMode,
  Direction,
  ExitingSnakeArrow,
  SnakeArrow,
} from '../types/game';
import { buildSnakeArrowGeometry, DIR_VECTOR } from '../engine/svgPath';

interface SnakeMazeBoardProps {
  rows: number;
  cols: number;
  mask: boolean[][];
  arrows: SnakeArrow[];
  totalArrows: number;
  streak: number;
  exitingArrows: ExitingSnakeArrow[];
  blockedFeedback: BlockedFeedback | null;
  hintArrowId: string | null;
  colorMode: ColorMode;
  onTapArrow: (arrow: SnakeArrow, boardWidthPx: number, boardHeightPx: number) => void;
}

const PRISM_PALETTE = [
  '#E4E4E7', // Platinum
  '#38BDF8', // Sky
  '#34D399', // Mint
  '#FBBF24', // Amber
  '#A78BFA', // Soft Violet
];

const RECOIL_CLASS: Record<Direction, string> = {
  up: 'animate-recoil-up',
  down: 'animate-recoil-down',
  left: 'animate-recoil-left',
  right: 'animate-recoil-right',
};

const PARTICLE_COUNT = 10;

const ExitingSnakeView: React.FC<{
  arrow: ExitingSnakeArrow;
  cellStep: number;
  offsetX: number;
  offsetY: number;
  exitDistance: number;
  strokeColor: string;
}> = ({ arrow, cellStep, offsetX, offsetY, exitDistance, strokeColor }) => {
  const pathRef = useRef<SVGPathElement>(null);
  const wakeRef = useRef<SVGPathElement>(null);
  const headRef = useRef<SVGPolygonElement>(null);
  const groupRef = useRef<SVGGElement>(null);
  const particleRefs = useRef<(SVGCircleElement | null)[]>([]);

  const geom = useMemo(
    () =>
      buildSnakeArrowGeometry(
        arrow.cells,
        arrow.dir,
        cellStep,
        offsetX,
        offsetY,
        exitDistance
      ),
    [arrow.cells, arrow.dir, cellStep, offsetX, offsetY, exitDistance]
  );

  const particleIndices = useMemo(
    () => Array.from({ length: PARTICLE_COUNT }, (_, i) => i),
    []
  );

  useLayoutEffect(() => {
    const pathEl = pathRef.current;
    const wakeEl = wakeRef.current;
    const headEl = headRef.current;
    const groupEl = groupRef.current;
    if (!pathEl || !headEl || !groupEl) return;

    const totalTravel = geom.restingLength + exitDistance;
    const v = DIR_VECTOR[arrow.dir];
    const perp = { x: -v.y, y: v.x };
    const duration = 340;
    const easing = 'cubic-bezier(0.32, 0, 0.2, 1)';

    pathEl.style.strokeDasharray = `${geom.restingLength} ${totalTravel + 80}`;
    pathEl.style.strokeDashoffset = '0';

    const animations: Animation[] = [];

    animations.push(
      pathEl.animate(
        [{ strokeDashoffset: 0 }, { strokeDashoffset: -totalTravel }],
        { duration, easing, fill: 'forwards' }
      )
    );

    if (wakeEl) {
      const wakeLen = Math.max(geom.restingLength * 0.65, 22);
      wakeEl.style.strokeDasharray = `${wakeLen} ${totalTravel + 80}`;
      wakeEl.style.strokeDashoffset = `${geom.restingLength * 0.35}`;
      animations.push(
        wakeEl.animate(
          [
            { strokeDashoffset: geom.restingLength * 0.35, opacity: 0.42 },
            { strokeDashoffset: -(totalTravel - wakeLen * 0.35), opacity: 0 },
          ],
          { duration: duration + 60, easing, fill: 'forwards' }
        )
      );
    }

    animations.push(
      headEl.animate(
        [
          { transform: 'translate3d(0px, 0px, 0)' },
          {
            transform: `translate3d(${(v.x * totalTravel).toFixed(2)}px, ${(
              v.y * totalTravel
            ).toFixed(2)}px, 0)`,
          },
        ],
        { duration, easing, fill: 'forwards' }
      )
    );

    animations.push(
      groupEl.animate(
        [
          { opacity: 1, offset: 0 },
          { opacity: 1, offset: 0.72 },
          { opacity: 0, offset: 1 },
        ],
        { duration: duration + 140, easing: 'ease-out', fill: 'forwards' }
      )
    );

    const reducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (!reducedMotion) {
      const fullPathLen = pathEl.getTotalLength();
      const startSample = Math.min(fullPathLen, geom.restingLength * 0.32);
      const spanSample = Math.max(10, fullPathLen * 0.85 - startSample);

      particleIndices.forEach((idx) => {
        const pEl = particleRefs.current[idx];
        if (!pEl || fullPathLen <= 0) return;

        const frac = idx / Math.max(1, PARTICLE_COUNT - 1);
        const sampleDist = Math.min(fullPathLen, startSample + frac * spanSample);
        const pt = pathEl.getPointAtLength(sampleDist);

        // Deterministic organic scatter perpendicular + slight drag opposite to travel
        const hash = Math.sin((idx + 1) * 12.9898 + arrow.cells.length * 78.233) * 43758.5453;
        const randA = hash - Math.floor(hash);
        const randB = ((hash * 1.37) % 1 + 1) % 1;

        const spreadPx = (randA - 0.5) * Math.max(14, cellStep * 0.9);
        const dragPx = 8 + randB * Math.max(12, cellStep * 0.65);

        const driftX = perp.x * spreadPx - v.x * dragPx;
        const driftY = perp.y * spreadPx - v.y * dragPx;
        const delay = Math.round(frac * 210);

        pEl.setAttribute('cx', pt.x.toFixed(2));
        pEl.setAttribute('cy', pt.y.toFixed(2));
        pEl.style.transformOrigin = `${pt.x.toFixed(2)}px ${pt.y.toFixed(2)}px`;
        pEl.style.opacity = '0';

        animations.push(
          pEl.animate(
            [
              { opacity: 0, transform: 'translate3d(0px, 0px, 0) scale(0.35)' },
              { opacity: 0.92, transform: 'translate3d(0px, 0px, 0) scale(1.15)', offset: 0.22 },
              {
                opacity: 0,
                transform: `translate3d(${driftX.toFixed(2)}px, ${driftY.toFixed(
                  2
                )}px, 0) scale(0.15)`,
              },
            ],
            {
              duration: 250,
              delay,
              easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
              fill: 'forwards',
            }
          )
        );
      });
    }

    return () => {
      animations.forEach((a) => a.cancel());
    };
  }, [geom, exitDistance, arrow.dir, arrow.cells.length, cellStep, particleIndices]);

  const baseParticleR = Math.max(1.3, Math.min(2.8, geom.strokeWidth * 0.52));

  return (
    <g ref={groupRef} className="pointer-events-none">
      {/* Subtle trailing slipstream wake */}
      <path
        ref={wakeRef}
        d={geom.exitPathD}
        fill="none"
        stroke={strokeColor}
        strokeWidth={geom.strokeWidth * 0.72}
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity="0.38"
      />

      {/* Primary exiting snake body */}
      <path
        ref={pathRef}
        d={geom.exitPathD}
        fill="none"
        stroke={strokeColor}
        strokeWidth={geom.strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polygon ref={headRef} points={geom.headPoints} fill={strokeColor} />

      {/* Trailing micro-particles */}
      {particleIndices.map((idx) => (
        <circle
          key={idx}
          ref={(el) => {
            particleRefs.current[idx] = el;
          }}
          r={idx % 2 === 0 ? baseParticleR : baseParticleR * 0.72}
          fill={strokeColor}
          opacity="0"
        />
      ))}
    </g>
  );
};

export const SnakeMazeBoard: React.FC<SnakeMazeBoardProps> = ({
  rows,
  cols,
  mask,
  arrows,
  totalArrows,
  streak,
  exitingArrows,
  blockedFeedback,
  hintArrowId,
  colorMode,
  onTapArrow,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [boxSize, setBoxSize] = useState<{ w: number; h: number }>({ w: 360, h: 360 });
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const dragRef = useRef<{
    active: boolean;
    startX: number;
    startY: number;
    origPanX: number;
    origPanY: number;
    moved: boolean;
    pendingArrow: SnakeArrow | null;
  }>({
    active: false,
    startX: 0,
    startY: 0,
    origPanX: 0,
    origPanY: 0,
    moved: false,
    pendingArrow: null,
  });

  // Reset zoom & pan whenever board dimensions change (new level)
  useEffect(() => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, [rows, cols]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const update = () => {
      const rect = el.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        setBoxSize({ w: Math.floor(rect.width), h: Math.floor(rect.height) });
      }
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const padding = 18;
  const availW = Math.max(100, boxSize.w - padding * 2);
  const availH = Math.max(100, boxSize.h - padding * 2);
  const cellStep = Math.min(availW / cols, availH / rows);
  const gridPixelW = cellStep * cols;
  const gridPixelH = cellStep * rows;
  const offsetX = (boxSize.w - gridPixelW) / 2;
  const offsetY = (boxSize.h - gridPixelH) / 2;
  const exitDistance = Math.max(boxSize.w, boxSize.h) * 0.95;

  const maskDots = useMemo(() => {
    const list: { x: number; y: number; key: string }[] = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (mask[r]?.[c]) {
          list.push({
            x: offsetX + (c + 0.5) * cellStep,
            y: offsetY + (r + 0.5) * cellStep,
            key: `${r}-${c}`,
          });
        }
      }
    }
    return list;
  }, [rows, cols, mask, offsetX, offsetY, cellStep]);

  const geometries = useMemo(() => {
    return arrows.map((arrow) => ({
      arrow,
      geom: buildSnakeArrowGeometry(
        arrow.cells,
        arrow.dir,
        cellStep,
        offsetX,
        offsetY,
        exitDistance
      ),
    }));
  }, [arrows, cellStep, offsetX, offsetY, exitDistance]);

  const clashVisual = useMemo(() => {
    if (!blockedFeedback) return null;
    const tapped = arrows.find((a) => a.id === blockedFeedback.tappedId);
    if (!tapped) return null;
    const head = tapped.cells[tapped.cells.length - 1];
    const startX = offsetX + (head.c + 0.5) * cellStep;
    const startY = offsetY + (head.r + 0.5) * cellStep;
    const endX = offsetX + (blockedFeedback.blockerCell.c + 0.5) * cellStep;
    const endY = offsetY + (blockedFeedback.blockerCell.r + 0.5) * cellStep;
    return { startX, startY, endX, endY };
  }, [blockedFeedback, arrows, offsetX, offsetY, cellStep]);

  const getStrokeColor = (arrow: SnakeArrow, isBlockedTapped: boolean, isBlocker: boolean, isHinted: boolean) => {
    if (isBlockedTapped || isBlocker) return '#FB7185';
    if (isHinted) return '#34D399';
    if (colorMode === 'prism') {
      return PRISM_PALETTE[arrow.colorIndex % PRISM_PALETTE.length];
    }
    return '#F4F4F5';
  };

  const clampPan = (nx: number, ny: number, z: number) => {
    if (z <= 1) return { x: 0, y: 0 };
    const maxX = (boxSize.w * (z - 1)) / 2 + 24;
    const maxY = (boxSize.h * (z - 1)) / 2 + 24;
    return {
      x: Math.max(-maxX, Math.min(maxX, nx)),
      y: Math.max(-maxY, Math.min(maxY, ny)),
    };
  };

  const handleToggleZoom = () => {
    const nextZoom = zoom === 1 ? 1.8 : zoom < 2.2 ? 2.6 : 1;
    setZoom(nextZoom);
    if (nextZoom === 1) {
      setPan({ x: 0, y: 0 });
    } else {
      setPan((p) => clampPan(p.x, p.y, nextZoom));
    }
  };

  const handleBoardPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (zoom <= 1) return;
    dragRef.current = {
      active: true,
      startX: e.clientX,
      startY: e.clientY,
      origPanX: pan.x,
      origPanY: pan.y,
      moved: false,
      pendingArrow: dragRef.current.pendingArrow,
    };
  };

  const handleBoardPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.active || zoom <= 1) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    if (Math.hypot(dx, dy) > 7) {
      dragRef.current.moved = true;
    }
    setPan(clampPan(dragRef.current.origPanX + dx, dragRef.current.origPanY + dy, zoom));
  };

  const handleBoardPointerUp = () => {
    if (zoom > 1 && !dragRef.current.moved && dragRef.current.pendingArrow) {
      onTapArrow(dragRef.current.pendingArrow, boxSize.w, boxSize.h);
    }
    dragRef.current.active = false;
    dragRef.current.pendingArrow = null;
    dragRef.current.moved = false;
  };

  const isDense = rows >= 10 || cols >= 10;

  // Compute dynamic ambient glow from flow streak & remaining board density
  const ambientFlow = useMemo(() => {
    const remainingRatio = totalArrows > 0 ? arrows.length / totalArrows : 0;
    // Dim smoothly as board nears empty
    const densityMultiplier =
      arrows.length === 0
        ? 0.08
        : remainingRatio <= 0.25
        ? 0.28 + (remainingRatio / 0.25) * 0.72
        : 1;

    if (streak >= 8) {
      return {
        gradient:
          'radial-gradient(circle at 50% 50%, rgba(251, 146, 60, 0.32) 0%, rgba(251, 191, 36, 0.14) 48%, rgba(0, 0, 0, 0) 76%)',
        borderColor: 'rgba(251, 191, 36, 0.24)',
        opacity: 0.95 * densityMultiplier,
        fastPulse: true,
      };
    }
    if (streak >= 4) {
      return {
        gradient:
          'radial-gradient(circle at 50% 50%, rgba(251, 191, 36, 0.25) 0%, rgba(245, 158, 11, 0.1) 50%, rgba(0, 0, 0, 0) 76%)',
        borderColor: 'rgba(251, 191, 36, 0.18)',
        opacity: 0.85 * densityMultiplier,
        fastPulse: true,
      };
    }
    if (streak >= 2) {
      return {
        gradient:
          'radial-gradient(circle at 50% 50%, rgba(52, 211, 153, 0.2) 0%, rgba(56, 189, 248, 0.08) 52%, rgba(0, 0, 0, 0) 76%)',
        borderColor: 'rgba(52, 211, 153, 0.16)',
        opacity: 0.72 * densityMultiplier,
        fastPulse: false,
      };
    }
    return {
      gradient:
        'radial-gradient(circle at 50% 50%, rgba(255, 255, 255, 0.075) 0%, rgba(255, 255, 255, 0.02) 52%, rgba(0, 0, 0, 0) 75%)',
      borderColor: 'rgba(255, 255, 255, 0.075)',
      opacity: 0.55 * densityMultiplier,
      fastPulse: false,
    };
  }, [streak, arrows.length, totalArrows]);

  return (
    <div className="relative flex items-center justify-center w-full h-full max-w-[min(96vw,540px)] max-h-[min(50dvh,480px)] lg:max-w-[min(52vw,600px)] lg:max-h-[min(74dvh,620px)]">
      {/* Subtle pulsing ambient halo behind the board */}
      <div
        className="pointer-events-none absolute -inset-5 sm:-inset-7 rounded-[2.25rem] transition-opacity duration-500 ease-out"
        style={{ opacity: ambientFlow.opacity }}
        aria-hidden="true"
      >
        <div
          className={`w-full h-full rounded-[2.25rem] blur-2xl transition-[background] duration-500 ease-out ${
            ambientFlow.fastPulse
              ? 'animate-ambient-breathe-fast'
              : 'animate-ambient-breathe'
          }`}
          style={{ background: ambientFlow.gradient }}
        />
      </div>

      <div
        ref={containerRef}
        onPointerDown={handleBoardPointerDown}
        onPointerMove={handleBoardPointerMove}
        onPointerUp={handleBoardPointerUp}
        onPointerCancel={handleBoardPointerUp}
        style={{ borderColor: ambientFlow.borderColor }}
        className={`relative z-10 w-full h-full rounded-3xl bg-[#040406] border shadow-[0_24px_70px_rgba(0,0,0,0.9)] ${
          zoom > 1 ? 'overflow-hidden' : 'overflow-visible'
        } touch-none select-none transition-[border-color] duration-500 ease-out`}
      >
        {/* Subtle radial OLED depth ambient light */}
        <div
          className="pointer-events-none absolute inset-0 rounded-3xl"
          style={{
            background:
              'radial-gradient(circle at 50% 48%, rgba(255,255,255,0.03) 0%, rgba(0,0,0,0) 70%)',
          }}
          aria-hidden="true"
        />

      {/* Zoom control button for dense master silhouettes */}
      {isDense && (
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={handleToggleZoom}
          aria-label={zoom === 1 ? 'Zoom in on maze' : 'Reset zoom'}
          className="absolute top-3 right-3 z-30 min-w-[44px] min-h-[44px] px-2.5 flex items-center justify-center gap-1.5 rounded-xl bg-[#0E0E13]/90 border border-white/[0.1] text-zinc-300 hover:text-white hover:border-white/25 active:scale-95 transition-all cursor-pointer backdrop-blur-md"
        >
          {zoom === 1 ? (
            <ZoomIn className="w-4 h-4" />
          ) : (
            <ZoomOut className="w-4 h-4 text-emerald-400" />
          )}
          <span className="text-[11px] font-mono tabular-nums">
            {zoom === 1 ? '1×' : `${zoom.toFixed(1)}×`}
          </span>
        </button>
      )}

      {/* Transformable Pan/Zoom Vector Stage */}
      <div
        className="w-full h-full origin-center transition-transform duration-150 ease-out"
        style={{
          transform: `translate3d(${pan.x}px, ${pan.y}px, 0) scale(${zoom})`,
          transitionProperty: dragRef.current.active ? 'none' : 'transform',
        }}
      >
        <svg
          width={boxSize.w}
          height={boxSize.h}
          viewBox={`0 0 ${boxSize.w} ${boxSize.h}`}
          className="block w-full h-full overflow-visible"
        >
          {/* Subtle micro-dot anchors inside active silhouette */}
          <g aria-hidden="true">
            {maskDots.map((dot) => (
              <circle
                key={dot.key}
                cx={dot.x}
                cy={dot.y}
                r={Math.max(0.8, cellStep * 0.04)}
                fill="rgba(255,255,255,0.09)"
              />
            ))}
          </g>

          {/* Clash trajectory line when tapping a blocked snake */}
          {clashVisual && (
            <g className="pointer-events-none" aria-hidden="true">
              <line
                x1={clashVisual.startX}
                y1={clashVisual.startY}
                x2={clashVisual.endX}
                y2={clashVisual.endY}
                stroke="rgba(251, 113, 133, 0.7)"
                strokeWidth="2"
                strokeDasharray="4 4"
                strokeLinecap="round"
              />
              <circle
                cx={clashVisual.endX}
                cy={clashVisual.endY}
                r={Math.max(4, cellStep * 0.16)}
                fill="rgba(251, 113, 133, 0.9)"
              />
            </g>
          )}

          {/* Active Winding Snake Arrows */}
          {geometries.map(({ arrow, geom }) => {
            const isBlockedTapped = blockedFeedback?.tappedId === arrow.id;
            const isBlocker = blockedFeedback?.blockerId === arrow.id;
            const isHinted = hintArrowId === arrow.id;
            const strokeColor = getStrokeColor(
              arrow,
              isBlockedTapped,
              isBlocker,
              isHinted
            );

            return (
              <g
                key={arrow.id}
                className={isBlockedTapped ? RECOIL_CLASS[arrow.dir] : undefined}
              >
                {/* Hint subtle outer halo */}
                {isHinted && (
                  <path
                    d={geom.restingPathD}
                    fill="none"
                    stroke="rgba(52, 211, 153, 0.3)"
                    strokeWidth={geom.strokeWidth * 3.1}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="pointer-events-none"
                  />
                )}

                {/* Visible crisp rounded snake body */}
                <path
                  d={geom.restingPathD}
                  fill="none"
                  stroke={strokeColor}
                  strokeWidth={geom.strokeWidth}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="pointer-events-none transition-colors duration-150"
                />

                {/* Sharp triangular arrowhead */}
                <polygon
                  points={geom.headPoints}
                  fill={strokeColor}
                  className="pointer-events-none transition-colors duration-150"
                />

                {/* Generous invisible touch hit corridor */}
                <path
                  d={geom.restingPathD}
                  fill="none"
                  stroke="transparent"
                  strokeWidth={geom.hitWidth}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="cursor-pointer"
                  onPointerDown={(e) => {
                    if (e.button !== 0 && e.pointerType === 'mouse') return;
                    if (zoom === 1) {
                      e.preventDefault();
                      e.stopPropagation();
                      onTapArrow(arrow, boxSize.w, boxSize.h);
                    } else {
                      dragRef.current.pendingArrow = arrow;
                    }
                  }}
                />
              </g>
            );
          })}

          {/* Non-blocking Slither-Out Exit Layer */}
          {exitingArrows.map((ex) => {
            const color =
              colorMode === 'prism'
                ? PRISM_PALETTE[ex.colorIndex % PRISM_PALETTE.length]
                : '#FFFFFF';
            return (
              <ExitingSnakeView
                key={ex.exitKey}
                arrow={ex}
                cellStep={cellStep}
                offsetX={offsetX}
                offsetY={offsetY}
                exitDistance={exitDistance}
                strokeColor={color}
              />
            );
          })}
        </svg>
      </div>
      </div>
    </div>
  );
};
