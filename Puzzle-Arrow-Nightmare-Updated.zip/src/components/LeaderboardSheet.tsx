import React, { useEffect, useMemo, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  Footprints,
  LogIn,
  LogOut,
  Pencil,
  Star,
  Trophy,
  X,
} from 'lucide-react';
import {
  formatDurationMs,
  LeaderboardEntry,
  LeaderboardSortMetric,
  LEVEL_MAX,
  LEVEL_MIN,
  PLAYER_NAME_MAX_LEN,
  sanitizePlayerName,
  subscribeToLevelLeaderboard,
} from '../engine/leaderboard';
import { getSilhouetteForLevel } from '../engine/silhouettes';

interface LeaderboardSheetProps {
  isOpen: boolean;
  initialLevel: number;
  maxUnlockedLevel: number;
  user: User | null;
  authReady: boolean;
  playerName: string;
  onUpdatePlayerName: (nextName: string) => void;
  onSignIn: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onPlayLevel: (levelNumber: number) => void;
  onClose: () => void;
}

const FEATURED_LEVELS = [1, 4, 10, 25, 50, 100, 150];

export const LeaderboardSheet: React.FC<LeaderboardSheetProps> = ({
  isOpen,
  initialLevel,
  maxUnlockedLevel,
  user,
  authReady,
  playerName,
  onUpdatePlayerName,
  onSignIn,
  onSignOut,
  onPlayLevel,
  onClose,
}) => {
  const [selectedLevel, setSelectedLevel] = useState<number>(initialLevel);
  const [sortBy, setSortBy] = useState<LeaderboardSortMetric>('bestTimeMs');
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [authBusy, setAuthBusy] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [editingName, setEditingName] = useState<boolean>(false);
  const [nameDraft, setNameDraft] = useState<string>(playerName);

  useEffect(() => {
    if (isOpen) {
      setSelectedLevel(
        Math.min(LEVEL_MAX, Math.max(LEVEL_MIN, Math.round(initialLevel)))
      );
      setAuthError(null);
      setLoadError(null);
    }
  }, [isOpen, initialLevel]);

  useEffect(() => {
    setNameDraft(playerName);
  }, [playerName]);

  useEffect(() => {
    if (!isOpen || !authReady || !user) {
      setEntries([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setLoadError(null);

    const unsubscribe = subscribeToLevelLeaderboard(
      selectedLevel,
      sortBy,
      (nextEntries) => {
        setEntries(nextEntries);
        setLoading(false);
      },
      (err) => {
        setLoading(false);
        setLoadError(err.message || 'Unable to load leaderboard.');
      }
    );

    return () => {
      unsubscribe();
    };
  }, [isOpen, authReady, user, selectedLevel, sortBy]);

  const quickLevels = useMemo(() => {
    const merged = new Set<number>([initialLevel, ...FEATURED_LEVELS]);
    return Array.from(merged)
      .filter((n) => n >= LEVEL_MIN && n <= LEVEL_MAX)
      .sort((a, b) => a - b);
  }, [initialLevel]);

  if (!isOpen) return null;

  const shape = getSilhouetteForLevel(selectedLevel);
  const isLevelUnlocked = selectedLevel <= maxUnlockedLevel;
  const myIndex = user
    ? entries.findIndex((entry) => entry.userId === user.uid)
    : -1;
  const myEntry = myIndex >= 0 ? entries[myIndex] : null;

  const handleSignInClick = async () => {
    setAuthBusy(true);
    setAuthError(null);
    try {
      await onSignIn();
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (!msg.includes('popup-closed-by-user')) {
        setAuthError('Sign-in could not be completed. Please try again.');
      }
    } finally {
      setAuthBusy(false);
    }
  };

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = sanitizePlayerName(nameDraft);
    onUpdatePlayerName(cleaned);
    setNameDraft(cleaned);
    setEditingName(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm"
      onPointerDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label="Level Leaderboards"
    >
      <div className="w-full max-w-lg max-h-[88dvh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-[#0A0A0D] border border-white/[0.1] shadow-2xl overflow-hidden animate-pop-in">
        {/* Mobile Drag Handle */}
        <div className="sm:hidden flex justify-center pt-3 pb-1 shrink-0">
          <div className="w-10 h-1 rounded-full bg-zinc-700" aria-hidden="true" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.07] shrink-0">
          <div className="flex items-center gap-2.5">
            <Trophy className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <h2 className="font-display text-lg font-semibold text-zinc-100 leading-tight">
                Level Leaderboard
              </h2>
              <p className="text-xs text-zinc-400">
                Best completion times &amp; least moves
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close leaderboard"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.06] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto dark-scroll p-5 space-y-4">
          {/* Level Selector */}
          <div className="p-3.5 rounded-2xl bg-[#131317] border border-white/[0.08] space-y-3">
            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() =>
                  setSelectedLevel((lvl) => Math.max(LEVEL_MIN, lvl - 1))
                }
                disabled={selectedLevel <= LEVEL_MIN}
                aria-label="Previous level"
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl bg-black/60 border border-white/[0.08] text-zinc-200 hover:border-white/20 disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <div className="text-center min-w-0">
                <div className="font-display text-base font-semibold text-white">
                  Level {selectedLevel}
                </div>
                <div className="text-xs text-zinc-400 truncate">
                  {shape.name} · {shape.rows}×{shape.cols}
                </div>
              </div>

              <button
                type="button"
                onClick={() =>
                  setSelectedLevel((lvl) => Math.min(LEVEL_MAX, lvl + 1))
                }
                disabled={selectedLevel >= LEVEL_MAX}
                aria-label="Next level"
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl bg-black/60 border border-white/[0.08] text-zinc-200 hover:border-white/20 disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Specific Level Quick Jumps */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 dark-scroll">
              {quickLevels.map((lvl) => {
                const active = lvl === selectedLevel;
                return (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setSelectedLevel(lvl)}
                    className={`min-h-[34px] px-2.5 rounded-lg text-xs font-mono tabular-nums shrink-0 border transition-colors cursor-pointer ${
                      active
                        ? 'bg-white text-black border-white font-semibold'
                        : 'bg-black/60 text-zinc-400 border-white/[0.07] hover:text-zinc-200 hover:border-white/[0.15]'
                    }`}
                  >
                    {lvl === initialLevel ? `Lv ${lvl} (Now)` : `Lv ${lvl}`}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sort Mode Toggle: Fastest Time vs Least Moves */}
          <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-[#111115] border border-white/[0.07]">
            <button
              type="button"
              onClick={() => setSortBy('bestTimeMs')}
              className={`min-h-[40px] rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                sortBy === 'bestTimeMs'
                  ? 'bg-[#22222A] text-amber-300 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Best Time</span>
            </button>
            <button
              type="button"
              onClick={() => setSortBy('bestMoves')}
              className={`min-h-[40px] rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                sortBy === 'bestMoves'
                  ? 'bg-[#22222A] text-emerald-300 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Footprints className="w-3.5 h-3.5" />
              <span>Least Moves</span>
            </button>
          </div>

          {/* Auth Gate or Live Firestore Leaderboard */}
          {!authReady ? (
            <div className="py-10 text-center text-xs text-zinc-400">
              Checking account status…
            </div>
          ) : !user ? (
            <div className="p-5 rounded-2xl bg-[#131317] border border-white/[0.08] text-center space-y-3">
              <div className="w-11 h-11 rounded-2xl bg-amber-400/12 border border-amber-400/30 flex items-center justify-center mx-auto">
                <Trophy className="w-5 h-5 text-amber-400" />
              </div>
              <div className="space-y-1">
                <div className="text-sm font-semibold text-white">
                  Global Cloud Leaderboards
                </div>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Sign in with Google to view live top times and lowest move
                  counts for each level, and sync your own personal bests.
                </p>
              </div>
              {authError && (
                <p className="text-xs text-rose-400">{authError}</p>
              )}
              <button
                type="button"
                onClick={handleSignInClick}
                disabled={authBusy}
                className="w-full min-h-[46px] rounded-xl bg-white hover:bg-zinc-200 text-black text-sm font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-50 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>
                  {authBusy ? 'Signing in…' : 'Continue with Google'}
                </span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {/* Public Handle Bar */}
              <div className="px-3.5 py-2.5 rounded-2xl bg-[#121217] border border-white/[0.07] flex items-center justify-between gap-2">
                {editingName ? (
                  <form
                    onSubmit={handleSaveName}
                    className="flex-1 flex items-center gap-2"
                  >
                    <input
                      type="text"
                      value={nameDraft}
                      maxLength={PLAYER_NAME_MAX_LEN}
                      onChange={(e) => setNameDraft(e.target.value)}
                      placeholder="Public handle"
                      aria-label="Public leaderboard handle"
                      className="flex-1 min-w-0 h-9 px-3 rounded-lg bg-black border border-white/[0.15] text-xs text-white focus:outline-none focus:border-emerald-400"
                    />
                    <button
                      type="submit"
                      aria-label="Save handle"
                      className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg bg-emerald-400 text-black hover:bg-emerald-300 cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  </form>
                ) : (
                  <>
                    <div className="min-w-0">
                      <div className="text-[11px] text-zinc-500">
                        Leaderboard Handle
                      </div>
                      <div className="text-xs font-medium text-zinc-100 truncate">
                        {playerName}
                        {myEntry && (
                          <span className="ml-2 text-emerald-400 font-mono">
                            #{myIndex + 1} · {formatDurationMs(myEntry.bestTimeMs)} ·{' '}
                            {myEntry.bestMoves} mv
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => setEditingName(true)}
                        aria-label="Edit public handle"
                        className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg text-zinc-400 hover:text-white hover:bg-white/[0.06] cursor-pointer"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={onSignOut}
                        aria-label="Sign out"
                        className="min-w-[36px] min-h-[36px] flex items-center justify-center rounded-lg text-zinc-400 hover:text-rose-300 hover:bg-white/[0.06] cursor-pointer"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </>
                )}
              </div>

              {/* Rankings List */}
              {loadError ? (
                <div className="p-4 rounded-2xl bg-rose-950/30 border border-rose-500/30 text-xs text-rose-200">
                  {loadError}
                </div>
              ) : loading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((row) => (
                    <div
                      key={row}
                      className="h-12 rounded-xl bg-[#131317] border border-white/[0.05]"
                    />
                  ))}
                </div>
              ) : entries.length === 0 ? (
                <div className="p-6 rounded-2xl bg-[#131317] border border-white/[0.07] text-center space-y-3">
                  <p className="text-xs text-zinc-400">
                    No records submitted for Level {selectedLevel} yet.
                  </p>
                  {isLevelUnlocked && (
                    <button
                      type="button"
                      onClick={() => {
                        onPlayLevel(selectedLevel);
                        onClose();
                      }}
                      className="min-h-[40px] px-4 rounded-xl bg-white hover:bg-zinc-200 text-black text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Play Level {selectedLevel}
                    </button>
                  )}
                </div>
              ) : (
                <div className="space-y-1.5">
                  {entries.map((entry, idx) => {
                    const rank = idx + 1;
                    const isMe = entry.userId === user.uid;
                    return (
                      <div
                        key={entry.userId}
                        className={`px-3.5 py-2.5 rounded-xl border flex items-center justify-between gap-3 ${
                          isMe
                            ? 'bg-emerald-500/10 border-emerald-500/35'
                            : 'bg-[#121216] border-white/[0.06]'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span
                            className={`w-7 text-xs font-mono tabular-nums font-bold shrink-0 ${
                              rank === 1
                                ? 'text-amber-400'
                                : rank === 2
                                ? 'text-zinc-200'
                                : rank === 3
                                ? 'text-orange-400'
                                : 'text-zinc-500'
                            }`}
                          >
                            #{rank}
                          </span>
                          <div className="min-w-0">
                            <div className="text-xs font-medium text-zinc-100 truncate">
                              {entry.playerName}
                              {isMe && (
                                <span className="ml-1.5 text-[10px] text-emerald-400 font-mono">
                                  (You)
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-0.5 mt-0.5">
                              {[1, 2, 3].map((s) => (
                                <Star
                                  key={s}
                                  className={`w-2.5 h-2.5 ${
                                    s <= entry.bestStars
                                      ? 'fill-amber-400 text-amber-400'
                                      : 'text-zinc-700'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 text-xs font-mono tabular-nums shrink-0">
                          <span
                            className={
                              sortBy === 'bestTimeMs'
                                ? 'text-amber-300 font-semibold'
                                : 'text-zinc-400'
                            }
                          >
                            {formatDurationMs(entry.bestTimeMs)}
                          </span>
                          <span
                            className={
                              sortBy === 'bestMoves'
                                ? 'text-emerald-300 font-semibold'
                                : 'text-zinc-400'
                            }
                          >
                            {entry.bestMoves} mv
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
