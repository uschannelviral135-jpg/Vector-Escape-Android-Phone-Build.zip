export type Direction = 'up' | 'right' | 'down' | 'left';

export interface CellCoord {
  r: number;
  c: number;
}

export interface SnakeArrow {
  id: string;
  /** Ordered from tail (index 0) to head (last index) */
  cells: CellCoord[];
  /** Direction the head points and exits along */
  dir: Direction;
  /** Optional subtle palette index for prism mode */
  colorIndex: number;
}

export interface SilhouetteShape {
  key: string;
  name: string;
  rows: number;
  cols: number;
  mask: boolean[][];
}

export interface LevelConfig {
  levelNumber: number;
  rows: number;
  cols: number;
  mask: boolean[][];
  shapeName: string;
  arrows: SnakeArrow[];
  maxLives: number;
}

export interface ExitingSnakeArrow extends SnakeArrow {
  exitKey: string;
  boardWidthPx: number;
  boardHeightPx: number;
}

export interface BlockedFeedback {
  tappedId: string;
  blockerId: string | null;
  blockerCell: CellCoord;
  timestamp: number;
}

export interface LevelProgress {
  stars: number; // 1..3
  bestMistakes: number;
  bestMoves: number;
}

export type GamePhase = 'PLAYING' | 'LEVEL_CLEAR' | 'GAME_OVER';

export type ColorMode = 'platinum' | 'prism';

export type ChallengeMode = 'hearts' | 'zen';

export interface AmbientSoundscapePrefs {
  digitalRain: boolean;
  lowHum: boolean;
  clockworkTicks: boolean;
}

export interface UserPreferences {
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  colorMode: ColorMode;
  challengeMode: ChallengeMode;
  soundscape: AmbientSoundscapePrefs;
}

export type PlayContext = 'campaign' | 'random' | 'daily';

export interface DailyBadgeDefinition {
  id: string;
  title: string;
  requirement: string;
  accent: 'emerald' | 'amber' | 'sky' | 'rose' | 'violet' | 'white';
}

export interface DailyCompletionRecord {
  dateKey: string;
  completedAt: number;
  totalMoves: number;
  totalMistakes: number;
}

export interface DailyProgressState {
  completedDates: Record<string, DailyCompletionRecord>;
  currentStreak: number;
  bestStreak: number;
  lastCompletedDate: string | null;
  unlockedBadges: string[];
  activeRun: {
    dateKey: string;
    stageIndex: number; // 0, 1, 2
    totalMoves: number;
    totalMistakes: number;
  } | null;
}
