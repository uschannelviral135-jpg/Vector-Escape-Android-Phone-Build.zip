import { CellCoord, Direction, LevelConfig, SilhouetteShape, SnakeArrow } from '../types/game';
import { getExtremeSilhouette, getSilhouetteForLevel } from './silhouettes';

const DIRECTIONS: Direction[] = ['up', 'right', 'down', 'left'];

const DIR_DELTA: Record<Direction, CellCoord> = {
  up: { r: -1, c: 0 },
  right: { r: 0, c: 1 },
  down: { r: 1, c: 0 },
  left: { r: 0, c: -1 },
};

const OPPOSITE_DIR: Record<Direction, Direction> = {
  up: 'down',
  down: 'up',
  left: 'right',
  right: 'left',
};

function createRng(seed: number) {
  let a = seed >>> 0;
  return function next(): number {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function getRayCellsFromHead(
  head: CellCoord,
  dir: Direction,
  rows: number,
  cols: number
): CellCoord[] {
  const d = DIR_DELTA[dir];
  const ray: CellCoord[] = [];
  let r = head.r + d.r;
  let c = head.c + d.c;
  while (r >= 0 && r < rows && c >= 0 && c < cols) {
    ray.push({ r, c });
    r += d.r;
    c += d.c;
  }
  return ray;
}

export interface PathCheckResult {
  clear: boolean;
  blockerId: string | null;
  blockerCell: CellCoord | null;
}

export function checkSnakeArrowPath(
  arrow: SnakeArrow,
  allArrows: SnakeArrow[],
  rows: number,
  cols: number
): PathCheckResult {
  const head = arrow.cells[arrow.cells.length - 1];
  const ray = getRayCellsFromHead(head, arrow.dir, rows, cols);
  if (ray.length === 0) {
    return { clear: true, blockerId: null, blockerCell: null };
  }

  const cellOwner = new Map<string, string>();
  for (const other of allArrows) {
    for (const cell of other.cells) {
      cellOwner.set(`${cell.r},${cell.c}`, other.id);
    }
  }

  for (const cell of ray) {
    const owner = cellOwner.get(`${cell.r},${cell.c}`);
    if (owner && owner !== arrow.id) {
      return { clear: false, blockerId: owner, blockerCell: cell };
    }
    if (owner === arrow.id) {
      return { clear: false, blockerId: arrow.id, blockerCell: cell };
    }
  }

  return { clear: true, blockerId: null, blockerCell: null };
}

/**
 * Exact fast topological solver verifying 100% solvability.
 */
export function isMazeSolvable(
  arrows: SnakeArrow[],
  rows: number,
  cols: number
): boolean {
  const grid: number[][] = Array.from({ length: rows }, () =>
    Array<number>(cols).fill(-1)
  );
  arrows.forEach((a, idx) => {
    for (const cell of a.cells) {
      grid[cell.r][cell.c] = idx;
    }
  });

  const removed = new Array<boolean>(arrows.length).fill(false);
  let remaining = arrows.length;

  while (remaining > 0) {
    let progressed = false;
    for (let i = 0; i < arrows.length; i++) {
      if (removed[i]) continue;
      const a = arrows[i];
      const head = a.cells[a.cells.length - 1];
      const d = DIR_DELTA[a.dir];
      let r = head.r + d.r;
      let c = head.c + d.c;
      let clear = true;
      while (r >= 0 && r < rows && c >= 0 && c < cols) {
        const occ = grid[r][c];
        if (occ !== -1 && !removed[occ]) {
          clear = false;
          break;
        }
        r += d.r;
        c += d.c;
      }
      if (clear) {
        removed[i] = true;
        remaining--;
        progressed = true;
      }
    }
    if (!progressed) return false;
  }
  return true;
}

/**
 * Finds the best clear arrow for Hint (prefers unlocking the most blocked arrows).
 */
export function findBestHintSnakeArrow(
  arrows: SnakeArrow[],
  rows: number,
  cols: number
): SnakeArrow | null {
  const clearArrows = arrows.filter(
    (a) => checkSnakeArrowPath(a, arrows, rows, cols).clear
  );
  if (clearArrows.length === 0) return null;
  if (clearArrows.length === 1) return clearArrows[0];

  let best = clearArrows[0];
  let bestUnlocked = -1;

  for (const candidate of clearArrows) {
    const rest = arrows.filter((a) => a.id !== candidate.id);
    const unlocked = rest.filter(
      (a) => checkSnakeArrowPath(a, rest, rows, cols).clear
    ).length;
    if (unlocked > bestUnlocked) {
      bestUnlocked = unlocked;
      best = candidate;
    }
  }

  return best;
}

interface GenerationDifficulty {
  minLen: number;
  maxLen: number;
  turnBias: number;
  interlockWeight: number;
  topSlice: number;
}

function getDifficultyParams(levelNumber: number): GenerationDifficulty {
  // Keep the opening levels welcoming, then ramp up density and interlocking.
  if (levelNumber <= 2) {
    return { minLen: 3, maxLen: 6, turnBias: 0.42, interlockWeight: 3, topSlice: 5 };
  }
  if (levelNumber <= 6) {
    return { minLen: 4, maxLen: 10, turnBias: 0.62, interlockWeight: 7, topSlice: 3 };
  }
  if (levelNumber <= 15) {
    return { minLen: 5, maxLen: 13, turnBias: 0.72, interlockWeight: 10, topSlice: 2 };
  }
  if (levelNumber <= 40) {
    return { minLen: 5, maxLen: 16, turnBias: 0.80, interlockWeight: 14, topSlice: 2 };
  }
  return { minLen: 6, maxLen: 18, turnBias: 0.86, interlockWeight: 18, topSlice: 1 };
}

function buildSinglePacking(
  levelNumber: number,
  rows: number,
  cols: number,
  mask: boolean[][],
  diff: GenerationDifficulty,
  seed: number
): { arrows: SnakeArrow[]; score: number } {
  const rng = createRng(seed);
  const occupied: number[][] = Array.from({ length: rows }, () =>
    Array<number>(cols).fill(-1)
  );
  const arrows: SnakeArrow[] = [];

  const inMaskFree = (r: number, c: number) =>
    r >= 0 && r < rows && c >= 0 && c < cols && mask[r][c] && occupied[r][c] === -1;

  const countFreeNeighbors = (r: number, c: number, selfSet: Set<string>) => {
    let count = 0;
    for (const dir of DIRECTIONS) {
      const nr = r + DIR_DELTA[dir].r;
      const nc = c + DIR_DELTA[dir].c;
      if (inMaskFree(nr, nc) && !selfSet.has(`${nr},${nc}`)) {
        count++;
      }
    }
    return count;
  };

  let interlockHits = 0;

  while (true) {
    const candidates: {
      head: CellCoord;
      neck: CellCoord;
      dir: Direction;
      blocksCount: number;
    }[] = [];

    const rayPressure = Array.from({ length: rows }, () =>
      Array<number>(cols).fill(0)
    );
    for (const existing of arrows) {
      const eh = existing.cells[existing.cells.length - 1];
      for (const rc of getRayCellsFromHead(eh, existing.dir, rows, cols)) {
        rayPressure[rc.r][rc.c]++;
      }
    }

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (!inMaskFree(r, c)) continue;

        for (const dir of DIRECTIONS) {
          const back = DIR_DELTA[OPPOSITE_DIR[dir]];
          const nr = r + back.r;
          const nc = c + back.c;
          if (!inMaskFree(nr, nc)) continue;

          const fd = DIR_DELTA[dir];
          let rr = r + fd.r;
          let cc = c + fd.c;
          let rayClear = true;
          let rayLen = 0;
          while (rr >= 0 && rr < rows && cc >= 0 && cc < cols) {
            if (occupied[rr][cc] !== -1) {
              rayClear = false;
              break;
            }
            rayLen++;
            rr += fd.r;
            cc += fd.c;
          }
          if (!rayClear) continue;

          const blocksCount = rayPressure[r][c] + rayPressure[nr][nc];
          // Early placements prefer long interior rays so later arrows lock them deeply
          const lockPotential = arrows.length < 18 ? Math.min(rayLen, 10) * 0.45 : 0;
          candidates.push({
            head: { r, c },
            neck: { r: nr, c: nc },
            dir,
            blocksCount: blocksCount + lockPotential,
          });
        }
      }
    }

    if (candidates.length === 0) break;

    candidates.sort((a, b) => b.blocksCount - a.blocksCount);
    const topSlice = Math.max(1, Math.min(candidates.length, diff.topSlice));
    const chosen = candidates[Math.floor(rng() * topSlice)];

    const forbiddenRay = new Set<string>();
    for (const rc of getRayCellsFromHead(chosen.head, chosen.dir, rows, cols)) {
      forbiddenRay.add(`${rc.r},${rc.c}`);
    }

    const reverseCells: CellCoord[] = [chosen.head, chosen.neck];
    const selfSet = new Set<string>([
      `${chosen.head.r},${chosen.head.c}`,
      `${chosen.neck.r},${chosen.neck.c}`,
    ]);

    const targetLen =
      diff.minLen + Math.floor(rng() * (diff.maxLen - diff.minLen + 1));
    let prevStepDir: Direction = OPPOSITE_DIR[chosen.dir];

    while (reverseCells.length < targetLen) {
      const curr = reverseCells[reverseCells.length - 1];
      const nextOptions: {
        cell: CellCoord;
        stepDir: Direction;
        score: number;
      }[] = [];

      for (const stepDir of DIRECTIONS) {
        const nr = curr.r + DIR_DELTA[stepDir].r;
        const nc = curr.c + DIR_DELTA[stepDir].c;
        const key = `${nr},${nc}`;
        if (!inMaskFree(nr, nc) || selfSet.has(key) || forbiddenRay.has(key)) {
          continue;
        }

        const openNeighbors = countFreeNeighbors(nr, nc, selfSet);
        const blocksScore = rayPressure[nr][nc] * diff.interlockWeight;
        const isTurn = stepDir !== prevStepDir;
        const turnScore = isTurn ? diff.turnBias * 3.4 : (1 - diff.turnBias) * 2.8;
        const hugScore = (4 - openNeighbors) * 2.4;

        nextOptions.push({
          cell: { r: nr, c: nc },
          stepDir,
          score: hugScore + blocksScore + turnScore + rng() * 1.4,
        });
      }

      if (nextOptions.length === 0) break;
      nextOptions.sort((a, b) => b.score - a.score);
      const bestNext = nextOptions[0];
      reverseCells.push(bestNext.cell);
      selfSet.add(`${bestNext.cell.r},${bestNext.cell.c}`);
      prevStepDir = bestNext.stepDir;
    }

    const cells = reverseCells.reverse();
    const arrowIndex = arrows.length;
    const arrow: SnakeArrow = {
      id: `lv${levelNumber}-s${arrowIndex}`,
      cells,
      dir: chosen.dir,
      colorIndex: arrowIndex % 5,
    };

    arrows.push(arrow);
    interlockHits += chosen.blocksCount;
    for (const c of cells) {
      occupied[c.r][c.c] = arrowIndex;
    }
  }

  // Orphan Cell Absorption Pass
  let absorbed = true;
  while (absorbed) {
    absorbed = false;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (!inMaskFree(r, c)) continue;

        for (const dir of DIRECTIONS) {
          const nr = r + DIR_DELTA[dir].r;
          const nc = c + DIR_DELTA[dir].c;
          if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue;
          const ownerIdx = occupied[nr][nc];
          if (ownerIdx === -1) continue;

          const owner = arrows[ownerIdx];
          const tail = owner.cells[0];
          if (tail.r !== nr || tail.c !== nc) continue;

          const ownerHead = owner.cells[owner.cells.length - 1];
          const onOwnRay = getRayCellsFromHead(ownerHead, owner.dir, rows, cols).some(
            (rc) => rc.r === r && rc.c === c
          );
          if (onOwnRay) continue;

          owner.cells.unshift({ r, c });
          if (isMazeSolvable(arrows, rows, cols)) {
            occupied[r][c] = ownerIdx;
            absorbed = true;
            break;
          } else {
            owner.cells.shift();
          }
        }
      }
    }
  }

  let totalMaskCells = 0;
  let filledCells = 0;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (mask[r][c]) {
        totalMaskCells++;
        if (occupied[r][c] !== -1) filledCells++;
      }
    }
  }

  const initialFree = arrows.filter(
    (a) => checkSnakeArrowPath(a, arrows, rows, cols).clear
  ).length;
  const fillRatio = totalMaskCells > 0 ? filledCells / totalMaskCells : 0;
  const bottleneckBonus = Math.max(0, arrows.length - initialFree * 3.5);
  const score = fillRatio * 140 + interlockHits * 2.5 + bottleneckBonus * 1.5;

  return { arrows, score };
}

function packBestBoard(
  levelNumber: number,
  shape: SilhouetteShape,
  diff: GenerationDifficulty,
  baseSeed: number,
  attempts: number
): LevelConfig {
  let best = buildSinglePacking(
    levelNumber,
    shape.rows,
    shape.cols,
    shape.mask,
    diff,
    baseSeed + 4242
  );

  for (let i = 1; i < attempts; i++) {
    const candidate = buildSinglePacking(
      levelNumber,
      shape.rows,
      shape.cols,
      shape.mask,
      diff,
      baseSeed + i * 31337 + 99
    );
    if (candidate.score > best.score) {
      best = candidate;
    }
  }

  return {
    levelNumber,
    rows: shape.rows,
    cols: shape.cols,
    mask: shape.mask,
    shapeName: shape.name,
    arrows: best.arrows,
    maxLives: 3,
  };
}

const levelCache = new Map<number, LevelConfig>();

export function generateLevel(levelNumber: number, customSeedOffset = 0): LevelConfig {
  if (customSeedOffset === 0 && levelCache.has(levelNumber)) {
    return levelCache.get(levelNumber)!;
  }

  const shape = getSilhouetteForLevel(levelNumber);
  const diff = getDifficultyParams(levelNumber);
  const attempts = levelNumber >= 14 ? 7 : 4;
  const config = packBestBoard(
    levelNumber,
    shape,
    diff,
    levelNumber * 7919 + customSeedOffset * 104729,
    attempts
  );

  if (customSeedOffset === 0) {
    levelCache.set(levelNumber, config);
  }
  return config;
}

export function generateExtremeBoard(seed: number): LevelConfig {
  const shape = getExtremeSilhouette(seed);
  const diff: GenerationDifficulty = {
    minLen: 6,
    maxLen: 18,
    turnBias: 0.88,
    interlockWeight: 19,
    topSlice: 1,
  };
  return packBestBoard(999, shape, diff, seed * 104729, 7);
}
