import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import { auth, db } from '../firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Validation constants synchronized verbatim with firebase-blueprint.json & firestore.rules
export const LEVEL_MIN = 1;
export const LEVEL_MAX = 150;
export const PLAYER_NAME_MAX_LEN = 24;
export const PLAYER_NAME_REGEX = /^[a-zA-Z0-9 ._\-]+$/;
export const SHAPE_NAME_MAX_LEN = 32;
export const SHAPE_NAME_REGEX = /^[a-zA-Z0-9 ._\-]+$/;
export const MOVES_MIN = 1;
export const MOVES_MAX = 10000;
export const TIME_MS_MIN = 100;
export const TIME_MS_MAX = 3600000;
export const STARS_MIN = 1;
export const STARS_MAX = 3;

export type LeaderboardSortMetric = 'bestTimeMs' | 'bestMoves';

export interface LeaderboardEntry {
  userId: string;
  playerName: string;
  levelNumber: number;
  shapeName: string;
  bestMoves: number;
  bestTimeMs: number;
  bestStars: number;
  createdAt?: Timestamp | null;
  updatedAt?: Timestamp | null;
}

export interface SubmitScoreInput {
  user: User;
  playerName: string;
  levelNumber: number;
  shapeName: string;
  moves: number;
  timeMs: number;
  stars: number;
}

export interface SubmitScoreResult {
  synced: boolean;
  isFirstRecord: boolean;
  isNewTimePB: boolean;
  isNewMovesPB: boolean;
  bestMoves: number;
  bestTimeMs: number;
}

export function sanitizePlayerName(raw: string): string {
  const cleaned = raw
    .trim()
    .replace(/[^a-zA-Z0-9 ._\-]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, PLAYER_NAME_MAX_LEN)
    .trim();
  if (!cleaned || !PLAYER_NAME_REGEX.test(cleaned)) {
    return 'Player';
  }
  return cleaned;
}

export function sanitizeShapeName(raw: string): string {
  const cleaned = raw
    .trim()
    .replace(/[^a-zA-Z0-9 ._\-]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, SHAPE_NAME_MAX_LEN)
    .trim();
  if (!cleaned || !SHAPE_NAME_REGEX.test(cleaned)) {
    return 'Vector Board';
  }
  return cleaned;
}

export function getLevelDocId(levelNumber: number): string {
  const safeLevel = Math.min(LEVEL_MAX, Math.max(LEVEL_MIN, Math.round(levelNumber)));
  return `level_${safeLevel}`;
}

export function formatDurationMs(ms: number): string {
  const clamped = Math.max(0, Math.round(ms));
  const totalSeconds = clamped / 1000;
  if (totalSeconds < 60) {
    return `${totalSeconds.toFixed(1)}s`;
  }
  const mins = Math.floor(totalSeconds / 60);
  const secs = (totalSeconds % 60).toFixed(1).padStart(4, '0');
  return `${mins}:${secs}`;
}

export function subscribeToLevelLeaderboard(
  levelNumber: number,
  sortBy: LeaderboardSortMetric,
  onData: (entries: LeaderboardEntry[]) => void,
  onError?: (err: Error) => void
): () => void {
  const levelId = getLevelDocId(levelNumber);
  const path = `levels/${levelId}/scores`;
  const scoresRef = collection(db, 'levels', levelId, 'scores');
  const q = query(scoresRef, orderBy(sortBy, 'asc'), limit(25));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: LeaderboardEntry[] = snapshot.docs.map((d) => {
        const data = d.data();
        return {
          userId: String(data.userId ?? d.id),
          playerName: String(data.playerName ?? 'Player'),
          levelNumber: Number(data.levelNumber ?? levelNumber),
          shapeName: String(data.shapeName ?? ''),
          bestMoves: Number(data.bestMoves ?? 0),
          bestTimeMs: Number(data.bestTimeMs ?? 0),
          bestStars: Number(data.bestStars ?? 1),
          createdAt: (data.createdAt as Timestamp | undefined) ?? null,
          updatedAt: (data.updatedAt as Timestamp | undefined) ?? null,
        };
      });
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        if (onError && wrapped instanceof Error) {
          onError(wrapped);
        } else {
          throw wrapped;
        }
      }
    }
  );
}

export async function submitLevelScore({
  user,
  playerName,
  levelNumber,
  shapeName,
  moves,
  timeMs,
  stars,
}: SubmitScoreInput): Promise<SubmitScoreResult> {
  const safeLevel = Math.min(LEVEL_MAX, Math.max(LEVEL_MIN, Math.round(levelNumber)));
  const safeMoves = Math.min(MOVES_MAX, Math.max(MOVES_MIN, Math.round(moves)));
  const safeTimeMs = Math.min(TIME_MS_MAX, Math.max(TIME_MS_MIN, Math.round(timeMs)));
  const safeStars = Math.min(STARS_MAX, Math.max(STARS_MIN, Math.round(stars)));
  const safePlayerName = sanitizePlayerName(playerName);
  const safeShapeName = sanitizeShapeName(shapeName);

  const levelId = getLevelDocId(safeLevel);
  const levelPath = `levels/${levelId}`;
  const scorePath = `levels/${levelId}/scores/${user.uid}`;
  const levelRef = doc(db, 'levels', levelId);
  const scoreRef = doc(db, 'levels', levelId, 'scores', user.uid);

  let levelExists = false;
  try {
    const levelSnap = await getDoc(levelRef);
    levelExists = levelSnap.exists();
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, levelPath);
  }

  let existingScore: LeaderboardEntry | null = null;
  try {
    const scoreSnap = await getDoc(scoreRef);
    if (scoreSnap.exists()) {
      const data = scoreSnap.data();
      existingScore = {
        userId: String(data.userId ?? user.uid),
        playerName: String(data.playerName ?? safePlayerName),
        levelNumber: Number(data.levelNumber ?? safeLevel),
        shapeName: String(data.shapeName ?? safeShapeName),
        bestMoves: Number(data.bestMoves ?? safeMoves),
        bestTimeMs: Number(data.bestTimeMs ?? safeTimeMs),
        bestStars: Number(data.bestStars ?? safeStars),
      };
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, scorePath);
  }

  if (existingScore) {
    const nextMoves = Math.min(existingScore.bestMoves, safeMoves);
    const nextTimeMs = Math.min(existingScore.bestTimeMs, safeTimeMs);
    const nextStars = Math.max(existingScore.bestStars, safeStars);
    const isNewMovesPB = safeMoves < existingScore.bestMoves;
    const isNewTimePB = safeTimeMs < existingScore.bestTimeMs;
    const isNewStarsPB = nextStars > existingScore.bestStars;
    const nameChanged = safePlayerName !== existingScore.playerName;

    if (!isNewMovesPB && !isNewTimePB && !isNewStarsPB && !nameChanged) {
      return {
        synced: false,
        isFirstRecord: false,
        isNewTimePB: false,
        isNewMovesPB: false,
        bestMoves: existingScore.bestMoves,
        bestTimeMs: existingScore.bestTimeMs,
      };
    }

    try {
      await updateDoc(scoreRef, {
        playerName: safePlayerName,
        shapeName: safeShapeName,
        bestMoves: nextMoves,
        bestTimeMs: nextTimeMs,
        bestStars: nextStars,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, scorePath);
    }

    return {
      synced: true,
      isFirstRecord: false,
      isNewTimePB,
      isNewMovesPB,
      bestMoves: nextMoves,
      bestTimeMs: nextTimeMs,
    };
  }

  const newScorePayload = {
    userId: user.uid,
    playerName: safePlayerName,
    levelNumber: safeLevel,
    shapeName: safeShapeName,
    bestMoves: safeMoves,
    bestTimeMs: safeTimeMs,
    bestStars: safeStars,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  if (!levelExists) {
    try {
      const batch = writeBatch(db);
      batch.set(levelRef, {
        levelNumber: safeLevel,
        shapeName: safeShapeName,
        createdAt: serverTimestamp(),
      });
      batch.set(scoreRef, newScorePayload);
      await batch.commit();
      return {
        synced: true,
        isFirstRecord: true,
        isNewTimePB: true,
        isNewMovesPB: true,
        bestMoves: safeMoves,
        bestTimeMs: safeTimeMs,
      };
    } catch (error) {
      // Handle race condition where another client created levelRef simultaneously
      try {
        const recheckLevel = await getDoc(levelRef);
        if (recheckLevel.exists()) {
          await setDoc(scoreRef, newScorePayload);
          return {
            synced: true,
            isFirstRecord: true,
            isNewTimePB: true,
            isNewMovesPB: true,
            bestMoves: safeMoves,
            bestTimeMs: safeTimeMs,
          };
        }
      } catch (retryError) {
        handleFirestoreError(retryError, OperationType.CREATE, scorePath);
      }
      handleFirestoreError(error, OperationType.CREATE, scorePath);
    }
  }

  try {
    await setDoc(scoreRef, newScorePayload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, scorePath);
  }

  return {
    synced: true,
    isFirstRecord: true,
    isNewTimePB: true,
    isNewMovesPB: true,
    bestMoves: safeMoves,
    bestTimeMs: safeTimeMs,
  };
}
