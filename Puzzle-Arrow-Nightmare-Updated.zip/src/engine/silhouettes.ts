import { SilhouetteShape } from '../types/game';

function parseAsciiMask(key: string, name: string, lines: string[]): SilhouetteShape {
  const rows = lines.length;
  const cols = Math.max(...lines.map((l) => l.length));
  const mask = lines.map((line) =>
    Array.from({ length: cols }, (_, c) => line[c] === '#')
  );
  return { key, name, rows, cols, mask };
}

function makeRectMask(key: string, name: string, rows: number, cols: number): SilhouetteShape {
  const mask = Array.from({ length: rows }, () => Array<boolean>(cols).fill(true));
  return { key, name, rows, cols, mask };
}

function makeHollowFrameMask(
  key: string,
  name: string,
  size: number,
  holeRadius: number
): SilhouetteShape {
  const center = Math.floor(size / 2);
  const mask = Array.from({ length: size }, (_, r) =>
    Array.from({ length: size }, (_, c) => {
      const dr = Math.abs(r - center);
      const dc = Math.abs(c - center);
      return !(dr <= holeRadius && dc <= holeRadius);
    })
  );
  return { key, name, rows: size, cols: size, mask };
}

function makeExtremeDiamond(size: number, name: string): SilhouetteShape {
  const mid = (size - 1) / 2;
  const mask = Array.from({ length: size }, (_, r) =>
    Array.from({ length: size }, (_, c) => Math.abs(r - mid) + Math.abs(c - mid) <= mid + 0.5)
  );
  return { key: `diamond_${size}`, name, rows: size, cols: size, mask };
}

const SILHOUETTES: Record<string, SilhouetteShape> = {
  intro_6: makeRectMask('intro_6', 'First Gate', 6, 6),
  compact_8: makeRectMask('compact_8', 'Crossroads', 8, 8),

  diamond_11: makeExtremeDiamond(11, 'Obsidian Diamond'),
  diamond_19: makeExtremeDiamond(19, 'Prism Diamond'),

  // Dense Chess Knight silhouette (18 rows x 16 cols)
  knight: parseAsciiMask('knight', 'The Knight', [
    '......#####.....',
    '....#########...',
    '...###########..',
    '..############..',
    '.##############.',
    '###############.',
    '#########.####..',
    '########..####..',
    '...#######......',
    '....########....',
    '....#########...',
    '...###########..',
    '..#############.',
    '.##############.',
    '################',
    '################',
    '################',
    '################',
  ]),

  // Extreme Dual-Plinth Chess Knight (22 rows x 19 cols — matches dense showcase style)
  knight_grand: parseAsciiMask('knight_grand', 'Extreme Knight', [
    '.......######......',
    '.....##########....',
    '....############...',
    '...##############..',
    '..###############..',
    '.#################.',
    '.#################.',
    '###########..####..',
    '#########....####..',
    '....########.......',
    '.....#########.....',
    '.....###########...',
    '....#############..',
    '...###############.',
    '..################.',
    '.##################',
    '.##################',
    '.##################',
    '...................',
    '###################',
    '###################',
    '###################',
  ]),

  hourglass_13: parseAsciiMask('hourglass_13', 'Hourglass', [
    '#############',
    '#############',
    '.###########.',
    '..#########..',
    '...#######...',
    '....#####....',
    '.....###.....',
    '....#####....',
    '...#######...',
    '..#########..',
    '.###########.',
    '#############',
    '#############',
  ]),

  twin_horizon_15: parseAsciiMask('twin_horizon_15', 'Twin Horizon', [
    '..###########..',
    '.#############.',
    '###############',
    '###############',
    '###############',
    '...............',
    '###############',
    '###############',
    '###############',
    '.#############.',
    '..###########..',
  ]),

  shield_14: parseAsciiMask('shield_14', 'Aegis Crest', [
    '##############',
    '##############',
    '##############',
    '##############',
    '##############',
    '##############',
    '.############.',
    '.############.',
    '..##########..',
    '..##########..',
    '...########...',
    '....######....',
    '.....####.....',
    '......##......',
  ]),

  crown_15: parseAsciiMask('crown_15', 'Sovereign Crown', [
    '#......#......#',
    '##....###....##',
    '###..#####..###',
    '###############',
    '###############',
    '###############',
    '###############',
    '.#############.',
    '.#############.',
    '..###########..',
    '..###########..',
  ]),

  heart_15: parseAsciiMask('heart_15', 'Pulse Core', [
    '..####...####..',
    '.######.######.',
    '###############',
    '###############',
    '###############',
    '###############',
    '.#############.',
    '..###########..',
    '...#########...',
    '....#######....',
    '.....#####.....',
    '......###......',
    '.......#.......',
  ]),

  citadel_18: parseAsciiMask('citadel_18', 'Obsidian Citadel', [
    '####..######..####',
    '####..######..####',
    '##################',
    '##################',
    '.################.',
    '.################.',
    '.################.',
    '.################.',
    '.################.',
    '.################.',
    '.################.',
    '.################.',
    '.################.',
    '##################',
    '##################',
    '##################',
  ]),

  monolith_12: makeRectMask('monolith_12', 'Monolith 12', 12, 12),
  labyrinth_14: makeRectMask('labyrinth_14', 'Labyrinth 14', 14, 14),
  vault_ring_15: makeHollowFrameMask('vault_ring_15', 'Vault Ring 15', 15, 2),
  nexus_16: makeRectMask('nexus_16', 'Grand Nexus 16', 16, 16),
  matrix_18: makeRectMask('matrix_18', 'Apex Matrix 18', 18, 18),
  omega_20: makeRectMask('omega_20', 'Omega Grid 20', 20, 20),
  vault_ring_21: makeHollowFrameMask('vault_ring_21', 'Extreme Ring 21', 21, 3),
  titan_22: makeRectMask('titan_22', 'Titan Grid 22', 22, 22),
  singularity_24: makeRectMask('singularity_24', 'Singularity 24', 24, 24),
};

const EARLY_SEQUENCE: string[] = [
  'intro_6',         // 1
  'compact_8',       // 2
  'diamond_11',      // 3
  'knight',          // 4 (Dense 18x16 Knight)
  'monolith_12',     // 5
  'hourglass_13',    // 6
  'twin_horizon_15', // 7
  'shield_14',       // 8
  'crown_15',        // 9
  'labyrinth_14',    // 10
  'heart_15',        // 11
  'vault_ring_15',   // 12
  'nexus_16',        // 13
  'knight_grand',    // 14 (22x19 Extreme Dual-Plinth Knight)
  'citadel_18',      // 15
  'matrix_18',       // 16
];

const MID_HARD_ROTATION: string[] = [
  'knight_grand',
  'nexus_16',
  'citadel_18',
  'diamond_19',
  'matrix_18',
  'omega_20',
  'vault_ring_21',
  'knight',
  'labyrinth_14',
  'titan_22',
];

const EXTREME_ROTATION: string[] = [
  'knight_grand',
  'omega_20',
  'vault_ring_21',
  'titan_22',
  'diamond_19',
  'singularity_24',
  'citadel_18',
  'matrix_18',
];

export function getSilhouetteForLevel(levelNumber: number): SilhouetteShape {
  const safeLvl = Number.isFinite(levelNumber) && levelNumber >= 1 ? Math.floor(levelNumber) : 1;
  if (safeLvl <= EARLY_SEQUENCE.length) {
    return SILHOUETTES[EARLY_SEQUENCE[safeLvl - 1]];
  }
  if (safeLvl <= 45) {
    const idx = (safeLvl - EARLY_SEQUENCE.length - 1) % MID_HARD_ROTATION.length;
    return SILHOUETTES[MID_HARD_ROTATION[idx]] ?? SILHOUETTES.omega_20;
  }
  const idx = (safeLvl - 46) % EXTREME_ROTATION.length;
  return SILHOUETTES[EXTREME_ROTATION[idx]] ?? SILHOUETTES.titan_22;
}

export function getExtremeSilhouette(seed: number): SilhouetteShape {
  return SILHOUETTES[EXTREME_ROTATION[Math.abs(seed) % EXTREME_ROTATION.length]];
}
