import { CellCoord, Direction } from '../types/game';

export const DIR_VECTOR: Record<Direction, { x: number; y: number }> = {
  up: { x: 0, y: -1 },
  right: { x: 1, y: 0 },
  down: { x: 0, y: 1 },
  left: { x: -1, y: 0 },
};

export const DIR_ANGLE: Record<Direction, number> = {
  up: 0,
  right: 90,
  down: 180,
  left: 270,
};

let measurerPath: SVGPathElement | null = null;

export function measureSvgPathLength(d: string): number {
  if (typeof document === 'undefined') return 100;
  if (!measurerPath) {
    measurerPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  }
  measurerPath.setAttribute('d', d);
  return measurerPath.getTotalLength();
}

export interface BuiltArrowGeometry {
  restingPathD: string;
  exitPathD: string;
  restingLength: number;
  headTip: { x: number; y: number };
  headPoints: string;
  strokeWidth: number;
  hitWidth: number;
}

export function buildSnakeArrowGeometry(
  cells: CellCoord[],
  dir: Direction,
  cellStep: number,
  offsetX: number,
  offsetY: number,
  exitDistance: number
): BuiltArrowGeometry {
  const pts = cells.map((cell) => ({
    x: offsetX + (cell.c + 0.5) * cellStep,
    y: offsetY + (cell.r + 0.5) * cellStep,
  }));

  const v = DIR_VECTOR[dir];
  const last = pts[pts.length - 1];

  // Razor-sharp stroke styling proportional to cell size for dense architectural mazes
  const strokeWidth = Math.max(1.85, Math.min(5.6, cellStep * 0.19));
  const hitWidth = Math.max(18, cellStep * 0.94);

  // Pull back stem end slightly so the pointed triangular arrowhead caps cleanly
  const tipOverlap = cellStep * 0.14;
  const stemEnd = {
    x: last.x - v.x * tipOverlap,
    y: last.y - v.y * tipOverlap,
  };

  // Build smoothed polyline with quadratic corners
  const adjustedPts = [...pts.slice(0, -1), stemEnd];
  const radius = Math.min(cellStep * 0.34, 14);

  let d = `M ${adjustedPts[0].x.toFixed(2)} ${adjustedPts[0].y.toFixed(2)}`;

  for (let i = 1; i < adjustedPts.length - 1; i++) {
    const prev = adjustedPts[i - 1];
    const curr = adjustedPts[i];
    const next = adjustedPts[i + 1];

    const dx1 = curr.x - prev.x;
    const dy1 = curr.y - prev.y;
    const len1 = Math.hypot(dx1, dy1);

    const dx2 = next.x - curr.x;
    const dy2 = next.y - curr.y;
    const len2 = Math.hypot(dx2, dy2);

    if (len1 < 0.01 || len2 < 0.01) continue;

    // Collinear check
    const ux1 = dx1 / len1;
    const uy1 = dy1 / len1;
    const ux2 = dx2 / len2;
    const uy2 = dy2 / len2;

    if (Math.abs(ux1 * uy2 - uy1 * ux2) < 0.01) {
      d += ` L ${curr.x.toFixed(2)} ${curr.y.toFixed(2)}`;
      continue;
    }

    const r = Math.min(radius, len1 * 0.48, len2 * 0.48);
    const pInX = curr.x - ux1 * r;
    const pInY = curr.y - uy1 * r;
    const pOutX = curr.x + ux2 * r;
    const pOutY = curr.y + uy2 * r;

    d += ` L ${pInX.toFixed(2)} ${pInY.toFixed(2)} Q ${curr.x.toFixed(2)} ${curr.y.toFixed(2)} ${pOutX.toFixed(2)} ${pOutY.toFixed(2)}`;
  }

  d += ` L ${stemEnd.x.toFixed(2)} ${stemEnd.y.toFixed(2)}`;

  const restingLength = measureSvgPathLength(d);

  // Exit path appends straight escape ray beyond stemEnd
  const exitEndX = stemEnd.x + v.x * exitDistance;
  const exitEndY = stemEnd.y + v.y * exitDistance;
  const exitPathD = `${d} L ${exitEndX.toFixed(2)} ${exitEndY.toFixed(2)}`;

  // Crisp arrowhead triangle centered at `last`, pointing in `dir`
  const headForward = Math.max(4.0, cellStep * 0.27);
  const headBack = Math.max(3.2, cellStep * 0.19);
  const headHalfWidth = Math.max(3.4, cellStep * 0.23);

  // Perpendicular vector
  const px = -v.y;
  const py = v.x;

  const tipX = last.x + v.x * headForward;
  const tipY = last.y + v.y * headForward;
  const baseLeftX = last.x - v.x * headBack + px * headHalfWidth;
  const baseLeftY = last.y - v.y * headBack + py * headHalfWidth;
  const baseRightX = last.x - v.x * headBack - px * headHalfWidth;
  const baseRightY = last.y - v.y * headBack - py * headHalfWidth;

  const headPoints = `${tipX.toFixed(2)},${tipY.toFixed(2)} ${baseLeftX.toFixed(2)},${baseLeftY.toFixed(2)} ${baseRightX.toFixed(2)},${baseRightY.toFixed(2)}`;

  return {
    restingPathD: d,
    exitPathD,
    restingLength,
    headTip: last,
    headPoints,
    strokeWidth,
    hitWidth,
  };
}
