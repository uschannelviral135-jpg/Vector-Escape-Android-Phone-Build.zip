import {
  DailyBadgeDefinition,
  DailyProgressState,
  LevelConfig,
} from '../types/game';
import { generateLevel } from './mazeGenerator';

export const DAILY_STAGE_COUNT = 3;

export const DAILY_BADGES: DailyBadgeDefinition[] = [
  {
    id: 'first_light',
    title: 'First Light',
    requirement: 'Complete 1 Daily Sequence',
    accent: 'emerald',
  },
  {
    id: 'flawless_run',
    title: 'Pure Precision',
    requirement: 'Finish a Daily Sequence with 0 bumps',
    accent: 'white',
  },
  {
    id: 'triad_streak',
    title: 'Triad Streak',
    requirement: '3 consecutive daily completions',
    accent: 'sky',
  },
  {
    id: 'five_victories',
    title: 'Aegis Envoy',
    requirement: 'Complete 5 Daily Sequences',
    accent: 'amber',
  },
  {
    id: 'obsidian_week',
    title: 'Obsidian Week',
    requirement: '7 consecutive daily completions',
    accent: 'violet',
  },
  {
    id: 'grandmaster_seal',
    title: 'Grandmaster Seal',
    requirement: 'Complete 14 Daily Sequences',
    accent: 'rose',
  },
];

export function getTodayDateKey(now = new Date()): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getYesterdayDateKey(now = new Date()): string {
  const yest = new Date(now);
  yest.setDate(yest.getDate() - 1);
  return getTodayDateKey(yest);
}

export function formatTimeUntilMidnight(now = new Date()): string {
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  const diffSec = Math.max(0, Math.floor((midnight.getTime() - now.getTime()) / 1000));
  const hrs = String(Math.floor(diffSec / 3600)).padStart(2, '0');
  const mins = String(Math.floor((diffSec % 3600) / 60)).padStart(2, '0');
  const secs = String(diffSec % 60).padStart(2, '0');
  return `${hrs}:${mins}:${secs}`;
}

export function formatReadableDate(dateKey: string): string {
  const [y, m, d] = dateKey.split('-').map((n) => parseInt(n, 10));
  const dt = new Date(y, (m || 1) - 1, d || 1);
  return dt.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

function hashDateKey(dateKey: string): number {
  let h = 2166136261;
  for (let i = 0; i < dateKey.length; i++) {
    h ^= dateKey.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h >>> 0);
}

/**
 * Generates the deterministic 3-stage Daily Challenge sequence for a given YYYY-MM-DD.
 * Stage 1: Medium sculpted silhouette
 * Stage 2: Challenging mid-tier silhouette (e.g. Knight, Crown, Vault Ring)
 * Stage 3: Master large silhouette (14x14 to 18x15)
 */
export function getDailySequence(dateKey: string): LevelConfig[] {
  const hash = hashDateKey(dateKey);

  const stage1Pool = [3, 5, 6, 7, 8];
  const stage2Pool = [4, 9, 10, 12, 13, 14, 15];
  const stage3Pool = [16, 20, 24, 28, 36, 44, 52];

  const s1Lvl = stage1Pool[hash % stage1Pool.length];
  const s2Lvl = stage2Pool[(hash >>> 4) % stage2Pool.length];
  const s3Lvl = stage3Pool[(hash >>> 8) % stage3Pool.length];

  return [
    generateLevel(s1Lvl, (hash % 5000) + 101),
    generateLevel(s2Lvl, ((hash >>> 3) % 5000) + 202),
    generateLevel(s3Lvl, ((hash >>> 6) % 5000) + 303),
  ];
}

export function computeEffectiveStreak(
  state: DailyProgressState,
  todayKey: string,
  yesterdayKey: string
): number {
  if (!state.lastCompletedDate) return 0;
  if (
    state.lastCompletedDate === todayKey ||
    state.lastCompletedDate === yesterdayKey
  ) {
    return state.currentStreak;
  }
  return 0;
}

export function applyDailyCompletion(
  prev: DailyProgressState,
  dateKey: string,
  yesterdayKey: string,
  totalMoves: number,
  totalMistakes: number
): { nextState: DailyProgressState; newlyUnlockedBadges: DailyBadgeDefinition[] } {
  if (prev.completedDates[dateKey]) {
    return { nextState: prev, newlyUnlockedBadges: [] };
  }

  const completedDates = {
    ...prev.completedDates,
    [dateKey]: {
      dateKey,
      completedAt: Date.now(),
      totalMoves,
      totalMistakes,
    },
  };

  const continuedStreak =
    prev.lastCompletedDate === yesterdayKey ? prev.currentStreak + 1 : 1;
  const bestStreak = Math.max(prev.bestStreak, continuedStreak);
  const totalCompleted = Object.keys(completedDates).length;

  const badgeSet = new Set(prev.unlockedBadges);
  const newlyUnlockedBadges: DailyBadgeDefinition[] = [];

  const maybeAward = (id: string, condition: boolean) => {
    if (condition && !badgeSet.has(id)) {
      badgeSet.add(id);
      const def = DAILY_BADGES.find((b) => b.id === id);
      if (def) newlyUnlockedBadges.push(def);
    }
  };

  maybeAward('first_light', totalCompleted >= 1);
  maybeAward('flawless_run', totalMistakes === 0);
  maybeAward('triad_streak', continuedStreak >= 3);
  maybeAward('five_victories', totalCompleted >= 5);
  maybeAward('obsidian_week', continuedStreak >= 7);
  maybeAward('grandmaster_seal', totalCompleted >= 14);

  return {
    nextState: {
      completedDates,
      currentStreak: continuedStreak,
      bestStreak,
      lastCompletedDate: dateKey,
      unlockedBadges: Array.from(badgeSet),
      activeRun: null,
    },
    newlyUnlockedBadges,
  };
}
