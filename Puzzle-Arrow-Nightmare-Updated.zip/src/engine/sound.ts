import { Capacitor } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

import { AmbientSoundscapePrefs } from '../types/game';

// Tactile Web Audio synthesizer, ambient soundscape layers & Android haptic engine

class SoundEngine {
  private ctx: AudioContext | null = null;
  public soundEnabled = true;
  public hapticsEnabled = true;

  // Ambient layer handles
  private rainNodes: {
    source: AudioBufferSourceNode;
    masterGain: GainNode;
    dropTimer: number;
  } | null = null;

  private humNodes: {
    osc1: OscillatorNode;
    osc2: OscillatorNode;
    osc3: OscillatorNode;
    lfo: OscillatorNode;
    masterGain: GainNode;
  } | null = null;

  private clockworkTimer: number | null = null;
  private clockworkStep = 0;

  private desiredAmbient: AmbientSoundscapePrefs = {
    digitalRain: false,
    lowHum: false,
    clockworkTicks: false,
  };

  private getOrCreateContext(createIfMissing = true): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx && createIfMissing) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private getSfxContext(): AudioContext | null {
    if (!this.soundEnabled) return null;
    return this.getOrCreateContext(true);
  }

  public unlockAndSyncAmbient() {
    const anyActive =
      this.desiredAmbient.digitalRain ||
      this.desiredAmbient.lowHum ||
      this.desiredAmbient.clockworkTicks;
    if (!anyActive) return;
    const ctx = this.getOrCreateContext(true);
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().then(() => {
        this.applyAmbientState(ctx);
      }).catch(() => {});
    } else if (ctx) {
      this.applyAmbientState(ctx);
    }
  }

  public syncAmbient(prefs: AmbientSoundscapePrefs) {
    this.desiredAmbient = { ...prefs };
    const anyActive = prefs.digitalRain || prefs.lowHum || prefs.clockworkTicks;
    const ctx = this.getOrCreateContext(anyActive);
    if (!ctx) return;
    this.applyAmbientState(ctx);
  }

  private applyAmbientState(ctx: AudioContext) {
    // 1. Digital Rain
    if (this.desiredAmbient.digitalRain && !this.rainNodes) {
      this.startDigitalRain(ctx);
    } else if (!this.desiredAmbient.digitalRain && this.rainNodes) {
      this.stopDigitalRain(ctx);
    }

    // 2. Low Hum
    if (this.desiredAmbient.lowHum && !this.humNodes) {
      this.startLowHum(ctx);
    } else if (!this.desiredAmbient.lowHum && this.humNodes) {
      this.stopLowHum(ctx);
    }

    // 3. Clockwork Ticks
    if (this.desiredAmbient.clockworkTicks && this.clockworkTimer === null) {
      this.startClockworkTicks();
    } else if (!this.desiredAmbient.clockworkTicks && this.clockworkTimer !== null) {
      this.stopClockworkTicks();
    }
  }

  private startDigitalRain(ctx: AudioContext) {
    const bufferSize = ctx.sampleRate * 3;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);

    // Smooth pink-ish filtered noise for gentle rain hiss
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.04;
      b6 = white * 0.115926;
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 1350;
    filter.Q.value = 0.65;

    const masterGain = ctx.createGain();
    const now = ctx.currentTime;
    masterGain.gain.setValueAtTime(0.0001, now);
    masterGain.gain.linearRampToValueAtTime(0.11, now + 0.45);

    source.connect(filter);
    filter.connect(masterGain);
    masterGain.connect(ctx.destination);
    source.start(now);

    // Occasional delicate crystalline "digital droplet" pings
    const dropNotes = [1046.5, 1174.66, 1318.51, 1567.98, 1760.0];
    const dropTimer = window.setInterval(() => {
      if (!this.desiredAmbient.digitalRain || ctx.state !== 'running') return;
      if (Math.random() > 0.58) return;
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      const freq = dropNotes[Math.floor(Math.random() * dropNotes.length)];
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.96, t + 0.14);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.016, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.2);
    }, 340);

    this.rainNodes = { source, masterGain, dropTimer };
  }

  private stopDigitalRain(ctx: AudioContext) {
    if (!this.rainNodes) return;
    const { source, masterGain, dropTimer } = this.rainNodes;
    this.rainNodes = null;
    window.clearInterval(dropTimer);
    const now = ctx.currentTime;
    try {
      masterGain.gain.cancelScheduledValues(now);
      masterGain.gain.setValueAtTime(masterGain.gain.value, now);
      masterGain.gain.linearRampToValueAtTime(0.0001, now + 0.25);
      source.stop(now + 0.28);
    } catch {
      // Ignore already stopped
    }
  }

  private startLowHum(ctx: AudioContext) {
    const now = ctx.currentTime;
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const osc3 = ctx.createOscillator();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    const masterGain = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(55, now); // A1 deep warm hum

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(82.41, now); // E2 warm fifth

    osc3.type = 'triangle';
    osc3.frequency.setValueAtTime(110, now); // A2 subtle harmonic

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(175, now);

    // Slow meditative breathing modulation
    lfo.type = 'sine';
    lfo.frequency.setValueAtTime(0.14, now);
    lfoGain.gain.setValueAtTime(0.014, now);

    const osc2Gain = ctx.createGain();
    osc2Gain.gain.setValueAtTime(0.42, now);
    const osc3Gain = ctx.createGain();
    osc3Gain.gain.setValueAtTime(0.18, now);

    masterGain.gain.setValueAtTime(0.0001, now);
    masterGain.gain.linearRampToValueAtTime(0.055, now + 0.55);

    lfo.connect(lfoGain);
    lfoGain.connect(masterGain.gain);

    osc1.connect(filter);
    osc2.connect(osc2Gain);
    osc2Gain.connect(filter);
    osc3.connect(osc3Gain);
    osc3Gain.connect(filter);

    filter.connect(masterGain);
    masterGain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc3.start(now);
    lfo.start(now);

    this.humNodes = { osc1, osc2, osc3, lfo, masterGain };
  }

  private stopLowHum(ctx: AudioContext) {
    if (!this.humNodes) return;
    const { osc1, osc2, osc3, lfo, masterGain } = this.humNodes;
    this.humNodes = null;
    const now = ctx.currentTime;
    try {
      masterGain.gain.cancelScheduledValues(now);
      masterGain.gain.setValueAtTime(masterGain.gain.value, now);
      masterGain.gain.linearRampToValueAtTime(0.0001, now + 0.3);
      const stopAt = now + 0.32;
      osc1.stop(stopAt);
      osc2.stop(stopAt);
      osc3.stop(stopAt);
      lfo.stop(stopAt);
    } catch {
      // Ignore
    }
  }

  private startClockworkTicks() {
    this.clockworkStep = 0;
    const tick = () => {
      if (!this.desiredAmbient.clockworkTicks) return;
      const ctx = this.getOrCreateContext(true);
      if (!ctx || ctx.state !== 'running') return;

      const t = ctx.currentTime;
      const isTock = this.clockworkStep % 2 === 1;
      this.clockworkStep++;

      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(isTock ? 920 : 1240, t);
      osc.frequency.exponentialRampToValueAtTime(isTock ? 420 : 560, t + 0.018);

      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(isTock ? 1400 : 1900, t);
      filter.Q.setValueAtTime(2.5, t);

      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.linearRampToValueAtTime(0.028, t + 0.002);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.024);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t);
      osc.stop(t + 0.03);
    };

    tick();
    this.clockworkTimer = window.setInterval(tick, 750);
  }

  private stopClockworkTicks() {
    if (this.clockworkTimer !== null) {
      window.clearInterval(this.clockworkTimer);
      this.clockworkTimer = null;
    }
  }

  public triggerHaptic(pattern: number | number[]) {
    if (!this.hapticsEnabled || typeof navigator === 'undefined') return;

    // Use the native Capacitor haptics bridge in the Android/iOS app.
    // Keep the browser vibration API as a graceful fallback for the PWA.
    if (Capacitor.isNativePlatform()) {
      const pulses = Array.isArray(pattern) ? pattern.filter((_, index) => index % 2 === 0) : [pattern];
      pulses.slice(0, 3).forEach((pulse, index) => {
        const style = pulse >= 22 ? ImpactStyle.Heavy : pulse >= 13 ? ImpactStyle.Medium : ImpactStyle.Light;
        window.setTimeout(() => {
          void Haptics.impact({ style }).catch(() => {});
        }, index * 65);
      });
      return;
    }

    if (typeof navigator.vibrate === 'function') {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Ignore on unsupported browsers
      }
    }
  }

  public playEscape(streak: number) {
    this.triggerHaptic(10);
    const ctx = this.getSfxContext();
    if (!ctx) return;

    const pentatonic = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5, 1174.66, 1318.51];
    const noteIndex = Math.min(Math.max(0, streak - 1), pentatonic.length - 1);
    const baseFreq = pentatonic[noteIndex];

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const oscHarmonic = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.18, now + 0.09);

    oscHarmonic.type = 'triangle';
    oscHarmonic.frequency.setValueAtTime(baseFreq * 2, now);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.11, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

    const harmonicGain = ctx.createGain();
    harmonicGain.gain.setValueAtTime(0.03, now);
    harmonicGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    osc.connect(gain);
    oscHarmonic.connect(harmonicGain);
    harmonicGain.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    oscHarmonic.start(now);
    osc.stop(now + 0.17);
    oscHarmonic.stop(now + 0.17);
  }

  public playBlocked() {
    this.triggerHaptic([16, 24, 16]);
    const ctx = this.getSfxContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(165, now);
    osc.frequency.exponentialRampToValueAtTime(82, now + 0.13);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.14, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.15);
  }

  public playUndo() {
    this.triggerHaptic(8);
    const ctx = this.getSfxContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(320, now + 0.09);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.11);
  }

  public playLevelClear() {
    this.triggerHaptic([15, 30, 25]);
    const ctx = this.getSfxContext();
    if (!ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.5];
    const now = ctx.currentTime;

    notes.forEach((freq, idx) => {
      const start = now + idx * 0.065;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, start);

      gain.gain.setValueAtTime(0.001, start);
      gain.gain.linearRampToValueAtTime(0.1, start + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.32);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(start);
      osc.stop(start + 0.34);
    });
  }
}

export const soundEngine = new SoundEngine();
