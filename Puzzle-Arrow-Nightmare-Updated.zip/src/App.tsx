import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Award,
  ArrowUpRight,
  Calendar,
  Check,
  Flame,
  Grid3X3,
  Heart,
  Lightbulb,
  Palette,
  RotateCcw,
  Settings2,
  Shuffle,
  Star,
  Trophy,
  Undo2,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { BadgeEmblem } from './components/BadgeEmblem';
import { DailyChallengeSheet } from './components/DailyChallengeSheet';
import { LeaderboardSheet } from './components/LeaderboardSheet';
import { LevelSelectSheet } from './components/LevelSelectSheet';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallButton } from './components/PWAInstallButton';
import { SettingsSheet } from './components/SettingsSheet';
import { SnakeMazeBoard } from './components/SnakeMazeBoard';
import {
  applyDailyCompletion,
  computeEffectiveStreak,
  DAILY_STAGE_COUNT,
  getDailySequence,
  getTodayDateKey,
  getYesterdayDateKey,
} from './engine/dailyChallenge';
import {
  formatDurationMs,
  sanitizePlayerName,
  submitLevelScore,
  SubmitScoreResult,
} from './engine/leaderboard';
import {
  checkSnakeArrowPath,
  findBestHintSnakeArrow,
  generateExtremeBoard,
  generateLevel,
} from './engine/mazeGenerator';
import { soundEngine } from './engine/sound';
import { auth, signInWithGoogle, signOutFirebase } from './firebase';
import {
  BlockedFeedback,
  DailyBadgeDefinition,
  DailyProgressState,
  ExitingSnakeArrow,
  GamePhase,
  LevelConfig,
  LevelProgress,
  PlayContext,
  SnakeArrow,
  UserPreferences,
} from './types/game';

const STORAGE_PROGRESS_KEY = 'vector_escape_maze_progress_v2';
const STORAGE_MAX_LEVEL_KEY = 'vector_escape_maze_max_level_v2';
const STORAGE_PREFS_KEY = 'vector_escape_maze_prefs_v2';
const STORAGE_DAILY_KEY = 'vector_escape_daily_v1';
const STORAGE_HANDLE_KEY = 'vector_escape_player_handle_v1';

const DEFAULT_PREFS: UserPreferences = {
  soundEnabled: true,
  hapticsEnabled: true,
  colorMode: 'platinum',
  challengeMode: 'hearts',
  soundscape: {
    digitalRain: false,
    lowHum: false,
    clockworkTicks: false,
  },
};

const DEFAULT_DAILY_STATE: DailyProgressState = {
  completedDates: {},
  currentStreak: 0,
  bestStreak: 0,
  lastCompletedDate: null,
  unlockedBadges: [],
  activeRun: null,
};

function loadPrefs(): UserPreferences {
  try {
    const raw = localStorage.getItem(STORAGE_PREFS_KEY);
    if (!raw) return DEFAULT_PREFS;
    const parsed = JSON.parse(raw) as Partial<UserPreferences>;
    return {
      ...DEFAULT_PREFS,
      ...parsed,
      soundscape: {
        ...DEFAULT_PREFS.soundscape,
        ...(parsed.soundscape || {}),
      },
    };
  } catch {
    return DEFAULT_PREFS;
  }
}

function loadProgress(): Record<number, LevelProgress> {
  try {
    const raw = localStorage.getItem(STORAGE_PROGRESS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function loadMaxLevel(): number {
  try {
    const raw = localStorage.getItem(STORAGE_MAX_LEVEL_KEY);
    const parsed = raw ? parseInt(raw, 10) : 1;
    return Number.isFinite(parsed) && parsed >= 1 ? parsed : 1;
  } catch {
    return 1;
  }
}

function loadDailyState(todayKey: string): DailyProgressState {
  try {
    const raw = localStorage.getItem(STORAGE_DAILY_KEY);
    if (!raw) return DEFAULT_DAILY_STATE;
    const parsed = { ...DEFAULT_DAILY_STATE, ...JSON.parse(raw) } as DailyProgressState;
    if (parsed.activeRun && parsed.activeRun.dateKey !== todayKey) {
      parsed.activeRun = null;
    }
    return parsed;
  } catch {
    return DEFAULT_DAILY_STATE;
  }
}

function calculateStars(mistakes: number): number {
  if (mistakes === 0) return 3;
  if (mistakes === 1) return 2;
  return 1;
}

export default function App() {
  const [todayKey, setTodayKey] = useState<string>(() => getTodayDateKey());
  const [showPremiumSplash, setShowPremiumSplash] = useState<boolean>(true);

  useEffect(() => {
    const splashTimer = window.setTimeout(() => setShowPremiumSplash(false), 1900);
    return () => window.clearTimeout(splashTimer);
  }, []);
  const [prefs, setPrefs] = useState<UserPreferences>(loadPrefs);
  const [progress, setProgress] = useState<Record<number, LevelProgress>>(loadProgress);
  const [maxUnlockedLevel, setMaxUnlockedLevel] = useState<number>(loadMaxLevel);
  const [dailyState, setDailyState] = useState<DailyProgressState>(() =>
    loadDailyState(getTodayDateKey())
  );

  const [playContext, setPlayContext] = useState<PlayContext>('campaign');
  const [currentLevelNum, setCurrentLevelNum] = useState<number>(() => loadMaxLevel());
  const [randomSeedOffset, setRandomSeedOffset] = useState<number>(0);

  // Daily Challenge active run state
  const [dailyStageIndex, setDailyStageIndex] = useState<number>(0);
  const [dailyTotals, setDailyTotals] = useState<{ moves: number; mistakes: number }>({
    moves: 0,
    mistakes: 0,
  });
  const [justEarnedBadges, setJustEarnedBadges] = useState<DailyBadgeDefinition[]>([]);

  const dailySequence = useMemo(() => getDailySequence(todayKey), [todayKey]);

  const levelConfig: LevelConfig = useMemo(() => {
    if (playContext === 'daily') {
      return dailySequence[dailyStageIndex] ?? dailySequence[0];
    }
    if (playContext === 'random') {
      return generateExtremeBoard(randomSeedOffset || 1);
    }
    return generateLevel(currentLevelNum, 0);
  }, [playContext, dailySequence, dailyStageIndex, currentLevelNum, randomSeedOffset]);

  const [arrows, setArrows] = useState<SnakeArrow[]>(() => levelConfig.arrows);
  const [history, setHistory] = useState<SnakeArrow[][]>([]);
  const [exitingArrows, setExitingArrows] = useState<ExitingSnakeArrow[]>([]);
  const [blockedFeedback, setBlockedFeedback] = useState<BlockedFeedback | null>(null);
  const [hintArrowId, setHintArrowId] = useState<string | null>(null);
  const [moves, setMoves] = useState<number>(0);
  const [movePulseTick, setMovePulseTick] = useState<number>(0);
  const [mistakes, setMistakes] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [comboPopup, setComboPopup] = useState<{ count: number; key: number } | null>(null);
  const [phase, setPhase] = useState<GamePhase>('PLAYING');

  const [isLevelSheetOpen, setIsLevelSheetOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isDailySheetOpen, setIsDailySheetOpen] = useState<boolean>(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState<boolean>(false);

  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState<boolean>(false);
  const [playerName, setPlayerName] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_HANDLE_KEY);
      return saved ? sanitizePlayerName(saved) : 'Player';
    } catch {
      return 'Player';
    }
  });
  const [lastRunTimeMs, setLastRunTimeMs] = useState<number>(0);
  const [leaderboardSync, setLeaderboardSync] = useState<{
    status: 'idle' | 'saving' | 'saved' | 'unchanged' | 'unauthenticated' | 'error';
    result?: SubmitScoreResult;
  }>({ status: 'idle' });

  const timersRef = useRef<number[]>([]);
  const lastClearTimeRef = useRef<number>(0);
  const rapidComboRef = useRef<number>(0);
  const comboHideTimerRef = useRef<number | null>(null);
  const runStartTimeRef = useRef<number>(Date.now());

  // Check for local midnight rollover every 30s
  useEffect(() => {
    const id = window.setInterval(() => {
      const nextKey = getTodayDateKey();
      if (nextKey !== todayKey) {
        setTodayKey(nextKey);
      }
    }, 30000);
    return () => window.clearInterval(id);
  }, [todayKey]);

  useEffect(() => {
    soundEngine.soundEnabled = prefs.soundEnabled;
    soundEngine.hapticsEnabled = prefs.hapticsEnabled;
    soundEngine.syncAmbient(prefs.soundscape);
    try {
      localStorage.setItem(STORAGE_PREFS_KEY, JSON.stringify(prefs));
    } catch {
      // Ignore storage errors
    }
  }, [prefs]);

  // Resume saved ambient soundscape on first user gesture
  useEffect(() => {
    const handleUnlock = () => {
      soundEngine.unlockAndSyncAmbient();
    };
    window.addEventListener('pointerdown', handleUnlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', handleUnlock);
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_DAILY_KEY, JSON.stringify(dailyState));
    } catch {
      // Ignore storage errors
    }
  }, [dailyState]);

  // Listen to Firebase Auth state for Cloud Leaderboards
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (nextUser) => {
      setFirebaseUser(nextUser);
      setAuthReady(true);
      if (nextUser?.displayName) {
        setPlayerName((curr) => {
          try {
            const saved = localStorage.getItem(STORAGE_HANDLE_KEY);
            if (saved) return sanitizePlayerName(saved);
          } catch {
            // Ignore storage errors
          }
          const fromAuth = sanitizePlayerName(nextUser.displayName || curr);
          return fromAuth;
        });
      }
    });
    return () => unsubscribe();
  }, []);

  const handleUpdatePlayerName = useCallback((nextName: string) => {
    const sanitized = sanitizePlayerName(nextName);
    setPlayerName(sanitized);
    try {
      localStorage.setItem(STORAGE_HANDLE_KEY, sanitized);
    } catch {
      // Ignore storage errors
    }
  }, []);

  useEffect(() => {
    return () => {
      timersRef.current.forEach((id) => window.clearTimeout(id));
      soundEngine.syncAmbient({
        digitalRain: false,
        lowHum: false,
        clockworkTicks: false,
      });
    };
  }, []);

  const clearPendingTimers = useCallback(() => {
    timersRef.current.forEach((id) => window.clearTimeout(id));
    timersRef.current = [];
    if (comboHideTimerRef.current !== null) {
      window.clearTimeout(comboHideTimerRef.current);
      comboHideTimerRef.current = null;
    }
  }, []);

  const resetBoardForConfig = useCallback(
    (nextConfig: LevelConfig) => {
      clearPendingTimers();
      setArrows(nextConfig.arrows);
      setHistory([]);
      setExitingArrows([]);
      setBlockedFeedback(null);
      setHintArrowId(null);
      setMoves(0);
      setMovePulseTick(0);
      setMistakes(0);
      setStreak(0);
      lastClearTimeRef.current = 0;
      rapidComboRef.current = 0;
      runStartTimeRef.current = Date.now();
      setLastRunTimeMs(0);
      setLeaderboardSync({ status: 'idle' });
      setComboPopup(null);
      setPhase('PLAYING');
    },
    [clearPendingTimers]
  );

  const startCampaignLevel = useCallback(
    (lvlNum: number, seedOffset = 0) => {
      const nextConfig = generateLevel(lvlNum, seedOffset);
      setPlayContext(seedOffset > 0 ? 'random' : 'campaign');
      setCurrentLevelNum(lvlNum);
      setRandomSeedOffset(seedOffset);
      setJustEarnedBadges([]);
      resetBoardForConfig(nextConfig);
    },
    [resetBoardForConfig]
  );

  const startDailyChallenge = useCallback(() => {
    const currentTodayKey = getTodayDateKey();
    if (currentTodayKey !== todayKey) {
      setTodayKey(currentTodayKey);
    }
    if (dailyState.completedDates[currentTodayKey]) {
      setIsDailySheetOpen(true);
      return;
    }

    const seq = getDailySequence(currentTodayKey);
    const resumeRun =
      dailyState.activeRun && dailyState.activeRun.dateKey === currentTodayKey
        ? dailyState.activeRun
        : null;

    const stageIdx = resumeRun
      ? Math.min(DAILY_STAGE_COUNT - 1, Math.max(0, resumeRun.stageIndex))
      : 0;
    const totals = resumeRun
      ? { moves: resumeRun.totalMoves, mistakes: resumeRun.totalMistakes }
      : { moves: 0, mistakes: 0 };

    setPlayContext('daily');
    setDailyStageIndex(stageIdx);
    setDailyTotals(totals);
    setJustEarnedBadges([]);
    resetBoardForConfig(seq[stageIdx]);
  }, [todayKey, dailyState, resetBoardForConfig]);

  const handleAdvanceDailyStage = useCallback(() => {
    const nextIdx = dailyStageIndex + 1;
    if (nextIdx >= DAILY_STAGE_COUNT) return;
    setDailyStageIndex(nextIdx);
    resetBoardForConfig(dailySequence[nextIdx]);
  }, [dailyStageIndex, dailySequence, resetBoardForConfig]);

  const handleRestart = useCallback(() => {
    soundEngine.triggerHaptic(8);
    resetBoardForConfig(levelConfig);
  }, [levelConfig, resetBoardForConfig]);

  const handlePlayRandom = useCallback(() => {
    const seed = Math.floor(Math.random() * 900000) + 1;
    const nextConfig = generateExtremeBoard(seed);
    setPlayContext('random');
    setRandomSeedOffset(seed);
    setJustEarnedBadges([]);
    resetBoardForConfig(nextConfig);
  }, [resetBoardForConfig]);

  const handleUpdatePrefs = useCallback((patch: Partial<UserPreferences>) => {
    setPrefs((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleTapArrow = useCallback(
    (tappedArrow: SnakeArrow, boardWidthPx: number, boardHeightPx: number) => {
      if (phase !== 'PLAYING') return;

      const result = checkSnakeArrowPath(
        tappedArrow,
        arrows,
        levelConfig.rows,
        levelConfig.cols
      );

      if (result.clear) {
        const nextStreak = streak + 1;
        const nextMoves = moves + 1;
        soundEngine.playEscape(nextStreak);

        const now = Date.now();
        if (now - lastClearTimeRef.current <= 1650) {
          rapidComboRef.current += 1;
        } else {
          rapidComboRef.current = 1;
        }
        lastClearTimeRef.current = now;

        if (rapidComboRef.current >= 2) {
          const comboCount = rapidComboRef.current;
          setComboPopup({ count: comboCount, key: now + Math.random() });
          if (comboHideTimerRef.current !== null) {
            window.clearTimeout(comboHideTimerRef.current);
          }
          comboHideTimerRef.current = window.setTimeout(() => {
            setComboPopup(null);
            comboHideTimerRef.current = null;
          }, 680);
        }

        const nextArrows = arrows.filter((a) => a.id !== tappedArrow.id);
        setHistory((prev) => [...prev, arrows]);
        setArrows(nextArrows);
        setMoves(nextMoves);
        setMovePulseTick((t) => t + 1);
        setStreak(nextStreak);
        setBlockedFeedback(null);
        setHintArrowId(null);

        const exitKey = `${tappedArrow.id}-${Date.now()}-${Math.random()}`;
        setExitingArrows((prev) => [
          ...prev,
          { ...tappedArrow, exitKey, boardWidthPx, boardHeightPx },
        ]);

        const exitTimer = window.setTimeout(() => {
          setExitingArrows((prev) => prev.filter((e) => e.exitKey !== exitKey));
        }, 520);
        timersRef.current.push(exitTimer);

        if (nextArrows.length === 0) {
          const elapsedMs = Math.max(100, Date.now() - runStartTimeRef.current);
          const winTimer = window.setTimeout(() => {
            soundEngine.playLevelClear();
            setLastRunTimeMs(elapsedMs);
            setPhase('LEVEL_CLEAR');

            if (playContext === 'daily') {
              const cumMoves = dailyTotals.moves + nextMoves;
              const cumMistakes = dailyTotals.mistakes + mistakes;
              setDailyTotals({ moves: cumMoves, mistakes: cumMistakes });

              if (dailyStageIndex < DAILY_STAGE_COUNT - 1) {
                setDailyState((prev) => ({
                  ...prev,
                  activeRun: {
                    dateKey: todayKey,
                    stageIndex: dailyStageIndex + 1,
                    totalMoves: cumMoves,
                    totalMistakes: cumMistakes,
                  },
                }));
              } else {
                const yesterdayKey = getYesterdayDateKey();
                setDailyState((prev) => {
                  const { nextState, newlyUnlockedBadges } = applyDailyCompletion(
                    prev,
                    todayKey,
                    yesterdayKey,
                    cumMoves,
                    cumMistakes
                  );
                  setJustEarnedBadges(newlyUnlockedBadges);
                  return nextState;
                });
              }
            } else if (playContext === 'campaign') {
              const earnedStars = calculateStars(mistakes);
              setProgress((prev) => {
                const existing = prev[currentLevelNum];
                const updated: Record<number, LevelProgress> = {
                  ...prev,
                  [currentLevelNum]: {
                    stars: existing ? Math.max(existing.stars, earnedStars) : earnedStars,
                    bestMoves: existing ? Math.min(existing.bestMoves, nextMoves) : nextMoves,
                    bestMistakes: existing
                      ? Math.min(existing.bestMistakes, mistakes)
                      : mistakes,
                  },
                };
                try {
                  localStorage.setItem(STORAGE_PROGRESS_KEY, JSON.stringify(updated));
                } catch {
                  // Ignore
                }
                return updated;
              });

              if (currentLevelNum >= maxUnlockedLevel) {
                const nextUnlocked = Math.min(150, currentLevelNum + 1);
                setMaxUnlockedLevel(nextUnlocked);
                try {
                  localStorage.setItem(STORAGE_MAX_LEVEL_KEY, String(nextUnlocked));
                } catch {
                  // Ignore
                }
              }

              if (firebaseUser) {
                setLeaderboardSync({ status: 'saving' });
                submitLevelScore({
                  user: firebaseUser,
                  playerName,
                  levelNumber: currentLevelNum,
                  shapeName: levelConfig.shapeName,
                  moves: nextMoves,
                  timeMs: elapsedMs,
                  stars: earnedStars,
                })
                  .then((res) => {
                    setLeaderboardSync({
                      status: res.synced ? 'saved' : 'unchanged',
                      result: res,
                    });
                  })
                  .catch(() => {
                    setLeaderboardSync({ status: 'error' });
                  });
              } else {
                setLeaderboardSync({ status: 'unauthenticated' });
              }
            }
          }, 300);
          timersRef.current.push(winTimer);
        }
      } else {
        soundEngine.playBlocked();
        const nextMistakes = mistakes + 1;
        setMistakes(nextMistakes);
        setStreak(0);
        lastClearTimeRef.current = 0;
        rapidComboRef.current = 0;
        setComboPopup(null);

        const head = tappedArrow.cells[tappedArrow.cells.length - 1];
        const feedback: BlockedFeedback = {
          tappedId: tappedArrow.id,
          blockerId: result.blockerId,
          blockerCell: result.blockerCell ?? head,
          timestamp: Date.now(),
        };
        setBlockedFeedback(feedback);

        const clearFeedbackTimer = window.setTimeout(() => {
          setBlockedFeedback((curr) =>
            curr && curr.timestamp === feedback.timestamp ? null : curr
          );
        }, 340);
        timersRef.current.push(clearFeedbackTimer);

        const usesHearts = playContext === 'daily' || prefs.challengeMode === 'hearts';
        if (usesHearts && nextMistakes >= levelConfig.maxLives) {
          const loseTimer = window.setTimeout(() => {
            setPhase('GAME_OVER');
          }, 280);
          timersRef.current.push(loseTimer);
        }
      }
    },
    [
      phase,
      arrows,
      levelConfig,
      streak,
      moves,
      mistakes,
      playContext,
      dailyTotals,
      dailyStageIndex,
      todayKey,
      currentLevelNum,
      maxUnlockedLevel,
      prefs.challengeMode,
      firebaseUser,
      playerName,
    ]
  );

  const handleUndo = useCallback(() => {
    if (history.length === 0 || phase !== 'PLAYING') return;
    soundEngine.playUndo();
    const prevBoard = history[history.length - 1];
    setHistory((prev) => prev.slice(0, -1));
    setArrows(prevBoard);
    setBlockedFeedback(null);
    setHintArrowId(null);
    setStreak(0);
    lastClearTimeRef.current = 0;
    rapidComboRef.current = 0;
    setComboPopup(null);
  }, [history, phase]);

  const handleHint = useCallback(() => {
    if (phase !== 'PLAYING') return;
    const best = findBestHintSnakeArrow(arrows, levelConfig.rows, levelConfig.cols);
    if (best) {
      soundEngine.triggerHaptic(10);
      setHintArrowId(best.id);
    }
  }, [phase, arrows, levelConfig]);

  const totalArrows = levelConfig.arrows.length;
  const clearedArrows = totalArrows - arrows.length;
  const progressPct = totalArrows > 0 ? Math.round((clearedArrows / totalArrows) * 100) : 0;
  const earnedStars = calculateStars(mistakes);
  const isThreeStarPace = mistakes === 0;
  const heartsRemaining = Math.max(0, levelConfig.maxLives - mistakes);
  const isDailyCompletedToday = Boolean(dailyState.completedDates[todayKey]);
  const effectiveDailyStreak = computeEffectiveStreak(
    dailyState,
    todayKey,
    getYesterdayDateKey()
  );

  const sidebarLevels = useMemo(() => {
    const start = Math.max(1, Math.min(currentLevelNum - 4, 136));
    return Array.from({ length: 15 }, (_, i) => start + i);
  }, [currentLevelNum]);

  const showHeartsBar = playContext === 'daily' || prefs.challengeMode === 'hearts';

  return (
    <div style={{ paddingTop: 'max(24px, env(safe-area-inset-top, 24px))', paddingBottom: 'max(0px, env(safe-area-inset-bottom, 0px))' }} className="box-border min-h-[100dvh] h-[100dvh] w-full bg-black text-zinc-100 flex flex-col overflow-hidden">
      {showPremiumSplash && (
        <div className="premium-splash fixed inset-0 z-[200] flex flex-col items-center justify-center overflow-hidden bg-[#050507]" role="status" aria-label="Loading Puzzle Arrow">
          <div className="splash-grid absolute inset-0 opacity-30" />
          <div className="splash-orbit absolute h-64 w-64 rounded-full border border-amber-300/10" />
          <div className="splash-orbit splash-orbit-delayed absolute h-48 w-48 rounded-full border border-white/10" />
          <div className="relative mb-7 flex h-24 w-24 items-center justify-center rounded-[2rem] border border-amber-200/25 bg-gradient-to-br from-[#292014] via-[#14110d] to-[#090909] shadow-[0_0_70px_rgba(245,185,75,0.16)]">
            <div className="absolute inset-1 rounded-[1.65rem] border border-white/[0.07]" />
            <ArrowUpRight className="h-12 w-12 text-amber-200" strokeWidth={1.8} />
            <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-amber-300 shadow-[0_0_18px_rgba(252,211,77,0.9)]" />
          </div>
          <div className="relative text-center">
            <div className="font-display text-3xl font-semibold tracking-[0.16em] text-white">PUZZLE ARROW</div>
            <div className="mt-2 text-[10px] font-semibold uppercase tracking-[0.42em] text-amber-200/65">Think · Trace · Escape</div>
          </div>
          <div className="relative mt-12 h-[2px] w-36 overflow-hidden rounded-full bg-white/10">
            <div className="splash-progress h-full rounded-full bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-400" />
          </div>
          <div className="relative mt-4 text-[10px] font-medium uppercase tracking-[0.28em] text-zinc-500">Preparing your puzzle</div>
        </div>
      )}
      {/* Compact Android Top Bar (<= 56px) */}
      <header className="shrink-0 h-14 px-4 sm:px-6 border-b border-white/[0.06] bg-black flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => setIsLevelSheetOpen(true)}
          className="flex items-baseline gap-2.5 min-w-0 cursor-pointer group focus-visible:outline-none"
        >
          <span className="font-display text-lg font-semibold tracking-tight text-white whitespace-nowrap shrink-0">
            Puzzle Arrow
          </span>
          <span className="text-xs text-zinc-500 font-mono tabular-nums whitespace-nowrap truncate group-hover:text-zinc-300 transition-colors">
            {playContext === 'daily'
              ? `Daily · ${dailyStageIndex + 1}/3 · ${levelConfig.shapeName}`
              : playContext === 'random'
              ? `Extreme · ${levelConfig.shapeName}`
              : `Lv ${currentLevelNum} · ${levelConfig.shapeName}`}
          </span>
        </button>

        <div className="flex items-center gap-1 shrink-0">
          <PWAInstallButton variant="compact" />

          <button
            type="button"
            onClick={() => setIsLeaderboardOpen(true)}
            aria-label="Open Level Leaderboards"
            className="min-w-[40px] min-h-[40px] px-2 flex items-center justify-center gap-1.5 rounded-xl bg-[#121216] border border-white/[0.09] text-zinc-200 hover:border-amber-400/40 hover:text-amber-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Trophy className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="hidden sm:inline text-xs font-medium">Ranks</span>
          </button>

          <button
            type="button"
            onClick={() => setIsDailySheetOpen(true)}
            aria-label="Open Daily Challenge"
            className={`min-h-[40px] px-2.5 flex items-center gap-1.5 rounded-xl border transition-colors cursor-pointer whitespace-nowrap ${
              playContext === 'daily'
                ? 'bg-amber-400/12 border-amber-400/40 text-amber-300'
                : isDailyCompletedToday
                ? 'bg-[#0F1512] border-emerald-500/25 text-emerald-300 hover:border-emerald-400/45'
                : 'bg-[#121216] border-white/[0.09] text-amber-300 hover:border-amber-400/40'
            }`}
          >
            {isDailyCompletedToday ? (
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <Calendar className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <span className="text-xs font-medium">Daily</span>
          </button>

          <button
            type="button"
            onClick={() => handleUpdatePrefs({ soundEnabled: !prefs.soundEnabled })}
            aria-label={prefs.soundEnabled ? 'Mute sound' : 'Enable sound'}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.06] transition-colors cursor-pointer"
          >
            {prefs.soundEnabled ? (
              <Volume2 className="w-5 h-5" />
            ) : (
              <VolumeX className="w-5 h-5 text-zinc-600" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setIsSettingsOpen(true)}
            aria-label="Open preferences"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-zinc-400 hover:text-zinc-100 hover:bg-white/[0.06] transition-colors cursor-pointer"
          >
            <Settings2 className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 min-h-0 w-full max-w-6xl mx-auto px-3 sm:px-6 py-2.5 lg:py-6 flex flex-col lg:flex-row lg:items-center lg:gap-10">
        {/* Left/Center: Active Labyrinth Stage */}
        <section className="flex-1 min-h-0 flex flex-col justify-between lg:justify-center">
          {/* Centered Hearts & Quiet Telemetry Row */}
          <div className="w-full max-w-[min(96vw,540px)] lg:max-w-[min(52vw,600px)] mx-auto mb-2 lg:mb-3.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs sm:text-sm font-mono tabular-nums min-w-0">
                <span
                  key={movePulseTick}
                  className={`inline-flex items-center gap-1 font-medium transition-colors duration-200 ${
                    movePulseTick > 0 ? 'animate-move-pulse' : ''
                  } ${isThreeStarPace ? 'text-amber-400' : 'text-zinc-300'}`}
                  aria-label={`${moves} ${moves === 1 ? 'move' : 'moves'}${
                    isThreeStarPace ? ', on 3-star pace' : ''
                  }`}
                >
                  {isThreeStarPace && (
                    <Star
                      className="w-3 h-3 fill-amber-400 text-amber-400 shrink-0"
                      aria-hidden="true"
                    />
                  )}
                  <span>{moves}</span>
                  <span className="text-[11px] opacity-80">
                    {moves === 1 ? 'move' : 'moves'}
                  </span>
                </span>
                <span className="text-zinc-600" aria-hidden="true">
                  ·
                </span>
                <span className="text-zinc-400 whitespace-nowrap">
                  <span className="text-zinc-200 font-medium">{arrows.length}</span>
                  <span> left</span>
                </span>
              </div>

              {showHeartsBar ? (
                <div
                  className="flex items-center justify-center gap-2"
                  aria-label={`${heartsRemaining} of 3 hearts remaining`}
                >
                  {[1, 2, 3].map((h) => (
                    <Heart
                      key={h}
                      className={`w-5 h-5 transition-all duration-200 ${
                        h <= heartsRemaining
                          ? 'fill-rose-500 text-rose-500 scale-100 drop-shadow-[0_0_8px_rgba(244,63,94,0.35)]'
                          : 'fill-transparent text-zinc-800 scale-90'
                      }`}
                    />
                  ))}
                </div>
              ) : (
                <span className="text-xs font-mono tabular-nums text-zinc-400">
                  Zen · {mistakes} {mistakes === 1 ? 'bump' : 'bumps'}
                </span>
              )}

              <div className="text-xs sm:text-sm font-mono tabular-nums text-right min-w-[68px]">
                {streak >= 2 ? (
                  <span className="text-emerald-400 font-semibold">{streak}× flow</span>
                ) : (
                  <span className="text-zinc-500">
                    {playContext === 'daily'
                      ? `Stage ${dailyStageIndex + 1}/3`
                      : `${levelConfig.rows}×${levelConfig.cols}`}
                  </span>
                )}
              </div>
            </div>

            <div className="mt-2 h-[2px] w-full rounded-full bg-zinc-900 overflow-hidden">
              <div
                className={`h-full transition-all duration-200 ease-out ${
                  playContext === 'daily' ? 'bg-amber-400' : 'bg-zinc-100'
                }`}
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>

          {/* Dominant Center-Stage Winding Snake Maze */}
          <div className="relative flex-1 min-h-0 flex items-center justify-center">
            <SnakeMazeBoard
              rows={levelConfig.rows}
              cols={levelConfig.cols}
              mask={levelConfig.mask}
              arrows={arrows}
              totalArrows={totalArrows}
              streak={streak}
              exitingArrows={exitingArrows}
              blockedFeedback={blockedFeedback}
              hintArrowId={hintArrowId}
              colorMode={prefs.colorMode}
              onTapArrow={handleTapArrow}
            />

            {/* Rapid-succession Combo xN floating popup */}
            {comboPopup && (
              <div
                key={comboPopup.key}
                aria-live="polite"
                className="pointer-events-none select-none absolute top-4 sm:top-6 left-1/2 -translate-x-1/2 z-30 animate-combo-flash"
              >
                <span
                  className={`font-display text-xl sm:text-2xl font-bold tracking-tight tabular-nums drop-shadow-[0_4px_18px_rgba(0,0,0,0.95)] whitespace-nowrap ${
                    comboPopup.count >= 7
                      ? 'text-orange-300'
                      : comboPopup.count >= 4
                      ? 'text-amber-300'
                      : 'text-emerald-300'
                  }`}
                >
                  Combo x{comboPopup.count}
                </span>
              </div>
            )}
          </div>

          {/* Bottom Thumb-Zone Action Dock */}
          <div className="shrink-0 w-full max-w-[min(96vw,540px)] lg:max-w-[min(52vw,600px)] mx-auto pt-2.5 pb-[max(0.45rem,env(safe-area-inset-bottom))]">
            <div className="grid grid-cols-4 gap-2">
              <button
                type="button"
                onClick={handleUndo}
                disabled={history.length === 0 || phase !== 'PLAYING'}
                className="min-h-[50px] flex flex-col items-center justify-center gap-1 rounded-2xl bg-[#0B0B0F] border border-white/[0.08] text-zinc-200 hover:bg-[#14141A] active:scale-[0.96] disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer"
              >
                <Undo2 className="w-4 h-4" />
                <span className="text-[11px] font-medium">Undo</span>
              </button>

              <button
                type="button"
                onClick={handleHint}
                disabled={arrows.length === 0 || phase !== 'PLAYING'}
                className="min-h-[50px] flex flex-col items-center justify-center gap-1 rounded-2xl bg-[#0B0B0F] border border-white/[0.08] text-emerald-300 hover:bg-[#14141A] active:scale-[0.96] disabled:opacity-35 disabled:pointer-events-none transition-all cursor-pointer"
              >
                <Lightbulb className="w-4 h-4" />
                <span className="text-[11px] font-medium">Hint</span>
              </button>

              <button
                type="button"
                onClick={handleRestart}
                className="min-h-[50px] flex flex-col items-center justify-center gap-1 rounded-2xl bg-[#0B0B0F] border border-white/[0.08] text-zinc-200 hover:bg-[#14141A] active:scale-[0.96] transition-all cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span className="text-[11px] font-medium">Restart</span>
              </button>

              <button
                type="button"
                onClick={() => setIsLevelSheetOpen(true)}
                className="min-h-[50px] flex flex-col items-center justify-center gap-1 rounded-2xl bg-[#0B0B0F] border border-white/[0.08] text-zinc-200 hover:bg-[#14141A] active:scale-[0.96] transition-all cursor-pointer lg:hidden"
              >
                <Grid3X3 className="w-4 h-4" />
                <span className="text-[11px] font-medium">Levels</span>
              </button>

              <button
                type="button"
                onClick={handlePlayRandom}
                className="hidden lg:flex min-h-[50px] flex-col items-center justify-center gap-1 rounded-2xl bg-[#130D10] border border-rose-500/30 text-rose-300 hover:bg-[#1C1217] active:scale-[0.96] transition-all cursor-pointer"
              >
                <Shuffle className="w-4 h-4" />
                <span className="text-[11px] font-medium">Extreme</span>
              </button>
            </div>
          </div>
        </section>

        {/* Desktop Companion Panel */}
        <aside className="hidden lg:flex w-[340px] xl:w-[370px] shrink-0 flex-col gap-5 rounded-3xl bg-[#08080B] border border-white/[0.08] p-6">
          {/* Daily Challenge Spotlight Block */}
          <div className="p-4 rounded-2xl bg-[#101015] border border-white/[0.08] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-amber-400" />
                <span className="font-display text-sm font-semibold text-white">
                  Daily Sequence
                </span>
              </div>
              <span className="flex items-center gap-1 text-xs font-mono tabular-nums text-zinc-400">
                <Flame
                  className={`w-3.5 h-3.5 ${
                    effectiveDailyStreak > 0 ? 'text-amber-400' : 'text-zinc-600'
                  }`}
                />
                <span>{effectiveDailyStreak}d</span>
              </span>
            </div>

            <div className="text-xs text-zinc-400 leading-relaxed">
              {isDailyCompletedToday
                ? `Today's 3-stage sequence cleared · ${dailyState.unlockedBadges.length} badges earned.`
                : 'Complete today’s 3-stage sequence once per 24 hours to unlock exclusive badges.'}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setIsDailySheetOpen(true)}
                className="min-h-[40px] px-2.5 rounded-xl bg-[#1A1A22] hover:bg-[#23232D] border border-white/[0.08] text-xs font-medium text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Award className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate">
                  {isDailyCompletedToday
                    ? 'Daily & Badges'
                    : playContext === 'daily'
                    ? `Stage ${dailyStageIndex + 1}/3`
                    : 'Daily Challenge'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setIsLeaderboardOpen(true)}
                className="min-h-[40px] px-2.5 rounded-xl bg-[#1A1A22] hover:bg-[#23232D] border border-white/[0.08] text-xs font-medium text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trophy className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate">Leaderboard</span>
              </button>
            </div>
          </div>

          <div className="border-t border-white/[0.07] pt-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-zinc-200">
                150 Chapters
              </span>
              <button
                type="button"
                onClick={() => setIsLevelSheetOpen(true)}
                className="text-xs font-medium text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer"
              >
                Browse all
              </button>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {sidebarLevels.map((lvl) => {
                const unlocked = lvl <= maxUnlockedLevel;
                const isCurrent =
                  playContext === 'campaign' && lvl === currentLevelNum;
                const stats = progress[lvl];

                return (
                  <button
                    key={lvl}
                    type="button"
                    disabled={!unlocked}
                    onClick={() => startCampaignLevel(lvl, 0)}
                    className={`min-h-[44px] flex flex-col items-center justify-center rounded-xl border text-xs font-mono tabular-nums transition-all ${
                      isCurrent
                        ? 'bg-white/10 border-white/60 text-white font-semibold'
                        : unlocked
                        ? 'bg-[#121216] border-white/[0.08] text-zinc-200 hover:border-white/25 cursor-pointer'
                        : 'bg-[#0A0A0D] border-white/[0.03] text-zinc-700 cursor-not-allowed'
                    }`}
                  >
                    <span>{lvl}</span>
                    {unlocked && (
                      <div className="flex gap-0.5 mt-0.5" aria-hidden="true">
                        {[1, 2, 3].map((s) => (
                          <span
                            key={s}
                            className={`w-1 h-1 rounded-full ${
                              stats && s <= stats.stars ? 'bg-amber-400' : 'bg-zinc-700'
                            }`}
                          />
                        ))}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="border-t border-white/[0.07] pt-4 space-y-2.5">
            <div className="flex items-center justify-between text-xs text-zinc-400">
              <span className="flex items-center gap-2">
                <Palette className="w-3.5 h-3.5 text-zinc-400" />
                <span>Path Style</span>
              </span>
              <button
                type="button"
                onClick={() =>
                  handleUpdatePrefs({
                    colorMode: prefs.colorMode === 'platinum' ? 'prism' : 'platinum',
                  })
                }
                className="text-zinc-200 hover:text-white font-medium cursor-pointer"
              >
                {prefs.colorMode === 'platinum' ? 'Platinum Ink' : 'Prism Tones'}
              </button>
            </div>

            <div className="flex items-center justify-between text-xs text-zinc-400">
              <span>Escape Rule</span>
              <button
                type="button"
                onClick={() =>
                  handleUpdatePrefs({
                    challengeMode: prefs.challengeMode === 'hearts' ? 'zen' : 'hearts',
                  })
                }
                className="text-zinc-200 hover:text-white font-medium cursor-pointer"
              >
                {prefs.challengeMode === 'hearts' ? '3 Hearts' : 'Zen Mode'}
              </button>
            </div>
          </div>
        </aside>
      </main>

      {/* Level / Daily Stage Clear Modal */}
      {phase === 'LEVEL_CLEAR' && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Puzzle Cleared"
        >
          <div className="w-full max-w-sm rounded-3xl bg-[#0C0C10] border border-white/[0.12] p-6 text-center shadow-2xl animate-pop-in">
            {playContext === 'daily' && dailyStageIndex === DAILY_STAGE_COUNT - 1 ? (
              <>
                <div className="w-12 h-12 rounded-2xl bg-amber-400/15 border border-amber-400/40 flex items-center justify-center mx-auto mb-3">
                  <Flame className="w-6 h-6 text-amber-400" />
                </div>
                <h2 className="font-display text-2xl font-semibold text-white">
                  Daily Complete
                </h2>
                <p className="text-sm text-zinc-400 mt-1 tabular-nums">
                  {dailyTotals.moves} taps · {dailyTotals.mistakes}{' '}
                  {dailyTotals.mistakes === 1 ? 'bump' : 'bumps'} ·{' '}
                  {effectiveDailyStreak}d streak
                </p>

                {justEarnedBadges.length > 0 && (
                  <div className="mt-4 p-3 rounded-2xl bg-[#131318] border border-white/[0.1] space-y-2 text-left">
                    <div className="text-xs font-medium text-amber-300">
                      New Badge{justEarnedBadges.length > 1 ? 's' : ''} Unlocked
                    </div>
                    {justEarnedBadges.map((b) => (
                      <div key={b.id} className="flex items-center gap-3">
                        <BadgeEmblem badge={b} unlocked size="sm" />
                        <div className="min-w-0">
                          <div className="text-sm font-medium text-white truncate">
                            {b.title}
                          </div>
                          <div className="text-xs text-zinc-400 truncate">
                            {b.requirement}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="mt-6 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      startCampaignLevel(currentLevelNum, 0);
                      setIsDailySheetOpen(true);
                    }}
                    className="flex-1 min-h-[48px] rounded-2xl bg-[#16161C] hover:bg-[#1E1E26] border border-white/[0.08] text-zinc-200 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
                  >
                    View Badges
                  </button>
                  <button
                    type="button"
                    onClick={() => startCampaignLevel(currentLevelNum, 0)}
                    className="flex-[1.2] min-h-[48px] rounded-2xl bg-white hover:bg-zinc-200 text-black text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Campaign
                  </button>
                </div>
              </>
            ) : playContext === 'daily' ? (
              <>
                <div className="text-xs font-mono text-amber-400 mb-2">
                  Daily Stage {dailyStageIndex + 1} of {DAILY_STAGE_COUNT}
                </div>
                <h2 className="font-display text-2xl font-semibold text-white">
                  {levelConfig.shapeName} Cleared
                </h2>
                <p className="text-sm text-zinc-400 mt-1 tabular-nums">
                  {moves} taps · {mistakes} {mistakes === 1 ? 'bump' : 'bumps'}
                </p>

                <div className="mt-6 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => startCampaignLevel(currentLevelNum, 0)}
                    className="flex-1 min-h-[48px] rounded-2xl bg-[#16161C] hover:bg-[#1E1E26] border border-white/[0.08] text-zinc-200 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Save &amp; Exit
                  </button>
                  <button
                    type="button"
                    onClick={handleAdvanceDailyStage}
                    className="flex-[1.4] min-h-[48px] rounded-2xl bg-amber-400 hover:bg-amber-300 text-black text-sm font-semibold transition-colors active:scale-[0.98] cursor-pointer whitespace-nowrap"
                  >
                    Stage {dailyStageIndex + 2} of 3
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center justify-center gap-2 mb-4">
                  {[1, 2, 3].map((s) => (
                    <Star
                      key={s}
                      className={`w-8 h-8 transition-transform ${
                        s <= earnedStars
                          ? 'text-amber-400 fill-amber-400 scale-100'
                          : 'text-zinc-800 scale-90'
                      }`}
                    />
                  ))}
                </div>

                <h2 className="font-display text-2xl font-semibold text-white">
                  {levelConfig.shapeName} Cleared
                </h2>
                <p className="text-sm text-zinc-400 mt-1 tabular-nums">
                  {moves} taps · {formatDurationMs(lastRunTimeMs)} · {mistakes}{' '}
                  {mistakes === 1 ? 'bump' : 'bumps'}
                </p>

                {playContext === 'campaign' && (
                  <div className="mt-3 flex items-center justify-center">
                    {leaderboardSync.status === 'saving' ? (
                      <span className="text-xs text-zinc-400">
                        Syncing to Leaderboard…
                      </span>
                    ) : leaderboardSync.status === 'saved' && leaderboardSync.result ? (
                      <button
                        type="button"
                        onClick={() => setIsLeaderboardOpen(true)}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-500/12 border border-emerald-500/30 text-xs font-medium text-emerald-300 hover:bg-emerald-500/20 transition-colors cursor-pointer"
                      >
                        <Trophy className="w-3.5 h-3.5" />
                        <span>
                          {leaderboardSync.result.isFirstRecord
                            ? 'Recorded on Leaderboard'
                            : leaderboardSync.result.isNewTimePB &&
                              leaderboardSync.result.isNewMovesPB
                            ? 'New Best Time & Least Moves!'
                            : leaderboardSync.result.isNewTimePB
                            ? 'New Best Time!'
                            : leaderboardSync.result.isNewMovesPB
                            ? 'New Least Moves!'
                            : 'Leaderboard Updated'}
                        </span>
                      </button>
                    ) : leaderboardSync.status === 'unchanged' ? (
                      <button
                        type="button"
                        onClick={() => setIsLeaderboardOpen(true)}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-white/[0.04] border border-white/[0.08] text-xs text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
                      >
                        <Trophy className="w-3.5 h-3.5 text-amber-400" />
                        <span>View Level {currentLevelNum} Ranks</span>
                      </button>
                    ) : leaderboardSync.status === 'unauthenticated' ? (
                      <button
                        type="button"
                        onClick={() => setIsLeaderboardOpen(true)}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-400/10 border border-amber-400/25 text-xs text-amber-300 hover:bg-amber-400/15 transition-colors cursor-pointer"
                      >
                        <Trophy className="w-3.5 h-3.5" />
                        <span>Sign in to save to Leaderboard</span>
                      </button>
                    ) : null}
                  </div>
                )}

                <div className="mt-6 flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleRestart}
                    className="flex-1 min-h-[48px] rounded-2xl bg-[#16161C] hover:bg-[#1E1E26] border border-white/[0.08] text-zinc-200 text-sm font-medium transition-colors active:scale-[0.98] cursor-pointer whitespace-nowrap"
                  >
                    Replay
                  </button>
                  {playContext === 'campaign' && (
                    <button
                      type="button"
                      onClick={() => setIsLeaderboardOpen(true)}
                      aria-label="View Level Ranks"
                      className="min-w-[48px] min-h-[48px] px-3 rounded-2xl bg-[#16161C] hover:bg-[#1E1E26] border border-white/[0.08] text-amber-300 flex items-center justify-center transition-colors active:scale-[0.98] cursor-pointer"
                    >
                      <Trophy className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() =>
                      playContext === 'random' || currentLevelNum >= 150
                        ? handlePlayRandom()
                        : startCampaignLevel(currentLevelNum + 1, 0)
                    }
                    className="flex-[1.4] min-h-[48px] rounded-2xl bg-white hover:bg-zinc-200 text-black text-sm font-semibold transition-colors active:scale-[0.98] cursor-pointer whitespace-nowrap"
                  >
                    {playContext === 'random'
                      ? 'Next Random'
                      : currentLevelNum >= 150
                      ? 'Master Random'
                      : 'Next Level'}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Out of Hearts Modal */}
      {phase === 'GAME_OVER' && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Out of Hearts"
        >
          <div className="w-full max-w-sm rounded-3xl bg-[#0C0C10] border border-rose-500/25 p-6 text-center shadow-2xl animate-pop-in">
            <div className="flex items-center justify-center gap-2 mb-3">
              {[1, 2, 3].map((h) => (
                <Heart key={h} className="w-6 h-6 text-zinc-800" />
              ))}
            </div>

            <h2 className="font-display text-2xl font-semibold text-white">
              Out of Hearts
            </h2>
            <p className="text-sm text-zinc-400 mt-1.5">
              {playContext === 'daily'
                ? 'Three blocked taps on this Daily stage. Retry the stage to keep your sequence alive.'
                : 'Three blocked taps in 3-Hearts mode. Try again or continue in Zen mode.'}
            </p>

            <div className="mt-6 flex items-center gap-3">
              {playContext === 'daily' ? (
                <button
                  type="button"
                  onClick={() => startCampaignLevel(currentLevelNum, 0)}
                  className="flex-1 min-h-[48px] rounded-2xl bg-[#16161C] hover:bg-[#1E1E26] border border-white/[0.08] text-zinc-300 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
                >
                  Exit Daily
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    handleUpdatePrefs({ challengeMode: 'zen' });
                    setPhase('PLAYING');
                  }}
                  className="flex-1 min-h-[48px] rounded-2xl bg-[#16161C] hover:bg-[#1E1E26] border border-white/[0.08] text-zinc-300 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
                >
                  Zen Mode
                </button>
              )}
              <button
                type="button"
                onClick={handleRestart}
                className="flex-1 min-h-[48px] rounded-2xl bg-rose-500 hover:bg-rose-400 text-black text-sm font-semibold transition-colors active:scale-[0.98] cursor-pointer whitespace-nowrap"
              >
                Try Again
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sheets */}
      <DailyChallengeSheet
        isOpen={isDailySheetOpen}
        dailyState={dailyState}
        dailySequence={dailySequence}
        todayKey={todayKey}
        onStartDaily={startDailyChallenge}
        onClose={() => setIsDailySheetOpen(false)}
      />

      <LevelSelectSheet
        isOpen={isLevelSheetOpen}
        currentLevel={currentLevelNum}
        maxUnlockedLevel={maxUnlockedLevel}
        totalLevels={150}
        progress={progress}
        onSelectLevel={(lvl) => startCampaignLevel(lvl, 0)}
        onPlayEndless={handlePlayRandom}
        onClose={() => setIsLevelSheetOpen(false)}
      />

      <SettingsSheet
        isOpen={isSettingsOpen}
        prefs={prefs}
        onUpdatePrefs={handleUpdatePrefs}
        onClose={() => setIsSettingsOpen(false)}
      />

      <LeaderboardSheet
        isOpen={isLeaderboardOpen}
        initialLevel={currentLevelNum}
        maxUnlockedLevel={maxUnlockedLevel}
        user={firebaseUser}
        authReady={authReady}
        playerName={playerName}
        onUpdatePlayerName={handleUpdatePlayerName}
        onSignIn={async () => {
          await signInWithGoogle();
        }}
        onSignOut={async () => {
          await signOutFirebase();
        }}
        onPlayLevel={(lvl) => startCampaignLevel(lvl, 0)}
        onClose={() => setIsLeaderboardOpen(false)}
      />

      <OfflineIndicator />
    </div>
  );
}
