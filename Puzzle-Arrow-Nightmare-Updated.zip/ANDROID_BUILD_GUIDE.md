# Puzzle Arrow — Android APK build

This project is a Vite + React web game. Capacitor packages it in a native Android WebView so GitHub Actions can build an installable debug APK.

## Build from GitHub Actions

1. Keep `Vector-Escape-Android-Phone-Build.zip` in the repository root.
2. Keep `.github/workflows/android-apk.yml` in the repository.
3. Open the repository's **Actions** tab.
4. Select **Build Puzzle Arrow APK** and choose **Run workflow**.
5. When the run succeeds, open the run and download the `Vector-Escape-APK` artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on an Android device. Android may ask you to allow installs from your browser or file manager.

## Notes

- The workflow uses Node.js 22 and Java 21.
- `npm run android:setup` builds the web assets, creates the Capacitor Android project, and syncs the web assets.
- This is a debug APK for testing, not a Play Store release-signed APK.
- If the game uses Firebase or Gemini services, configure the required service settings/secrets separately. Do not commit private API keys.
