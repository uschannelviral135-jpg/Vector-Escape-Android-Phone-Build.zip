# Security Specification — Vector Escape Firestore Leaderboard

## 1. Data Invariants
1. **Strict Level Range**: Only campaign levels `1..150` may have leaderboard rooms (`level_1`..`level_150`), and `levelId` must equal `'level_' + string(levelNumber)`.
2. **Master Gate & Atomicity**: Every score write under `/levels/{levelId}/scores/{userId}` requires `/levels/{levelId}` to exist (either already present on `update`, or present via `existsAfter` / `getAfter` in the same atomic batch on `create`) with matching `levelNumber`.
3. **Strict Ownership & Verified Identity**: Only signed-in, email-verified Google users (`request.auth.token.email_verified == true`) may create or update scores, and only under their own `{userId}` (`request.auth.uid == userId` and `incoming().userId == request.auth.uid`).
4. **Zero PII Exposure**: Public `LevelScore` documents may never contain `email`, `phone`, or `photoURL`; only sanitized `playerName` (`<= 24` chars matching `^[a-zA-Z0-9 ._\\-]+$`).
5. **Monotonic Score Integrity**: Updates may only improve or maintain `bestMoves`, `bestTimeMs`, and `bestStars` (`incoming().bestMoves <= existing().bestMoves`, `incoming().bestTimeMs <= existing().bestTimeMs`, `incoming().bestStars >= existing().bestStars`), while keeping `userId`, `levelNumber`, and `createdAt` immutable.
6. **Temporal Integrity**: `createdAt` and `updatedAt` must strictly equal `request.time`.

## 2. The "Dirty Dozen" Attack Payloads
1. **Unauthenticated Write**: Anonymous client tries to `setDoc` `/levels/level_1/scores/attacker`. Expected: `PERMISSION_DENIED`.
2. **Unverified Email Spoof**: Signed-in user with `email_verified: false` attempts to write a score. Expected: `PERMISSION_DENIED`.
3. **Identity Spoofing (Document Path)**: User `alice` tries to write `/levels/level_1/scores/bob` with `userId: 'bob'`. Expected: `PERMISSION_DENIED`.
4. **Identity Spoofing (Payload UID)**: User `alice` tries to write `/levels/level_1/scores/alice` with `userId: 'bob'`. Expected: `PERMISSION_DENIED`.
5. **Shadow / Ghost Field Injection**: User `alice` includes `isAdmin: true` or `email: 'alice@example.com'` in a score document. Expected: `PERMISSION_DENIED`.
6. **ID Poisoning**: Attacker targets `/levels/level_1/scores/../../../../etc/passwd` or a 500-char ID. Expected: `PERMISSION_DENIED`.
7. **Out-of-Range Level Number**: User creates `/levels/level_999` or `/levels/level_1` with `levelNumber: 2` (mismatch). Expected: `PERMISSION_DENIED`.
8. **Impossible Score / Value Poisoning**: User submits `bestMoves: 0` or `bestTimeMs: -50` or `bestStars: 99`. Expected: `PERMISSION_DENIED`.
9. **Score Regression / Tampering**: User updates existing score to make `bestMoves` worse (`10 -> 20`) or alter `createdAt`. Expected: `PERMISSION_DENIED`.
10. **Client-Forged Timestamp**: User submits `updatedAt: new Date(0)` instead of `serverTimestamp()`. Expected: `PERMISSION_DENIED`.
11. **Oversized String / Denial-of-Wallet**: User submits a 10KB `playerName` or `shapeName`. Expected: `PERMISSION_DENIED`.
12. **Orphaned Score Without Parent LevelBoard**: User writes `/levels/level_42/scores/alice` without `/levels/level_42` existing or being created atomically in the batch. Expected: `PERMISSION_DENIED`.
